/*  $Id: bundle.cpp,v 1.1 2006/05/26 00:45:32 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <sstream>
#include <vector>
#include <stdexcept>
#include <iostream>
#include <fstream>

#include "system.hpp"

/* 
   File Layout:
   
   offset
   text_count
   data: width 20 bytes each
   followed by data with 32 or 64 width
   followed by unknown
   followed by something with width 76
   followed by something with width 28
   
   some data seems to be the alphabet, some other data seems to be skeleton structure 
   
   0002.dat might contain the scene 3d model!
 */
//tower_square.bun

bool is_uv(float f)
{
  return f <= 1.0f and f >= -1.0f;
}

bool is_one_or_zero(float f)
{
  if (f == -1.0f || f == 1.0f || f == 0.0f)
    return true;
  else if (f < 0.000001f and f > -0.000001f)
    return true;
  else
    return false;
}
/*
block sizes used: 
      8 block: 12
   5315 block: 20
     20 block: 24
     20 block: 28
      4 block: 32
    557 block: 44
    848 block: 56
   1527 block: 60
   1905 block: 64
     31 block: 72
    544 block: 76
     14 block: 80

*/

std::string directory_name_from_bun(const std::string& name)
{
  std::string::size_type pos1 = name.find_last_of('\\');
  std::string::size_type pos2 = name.find_last_of('/');
  std::string::size_type dotpos = name.find_last_of('.');
  std::string::size_type namestart;

  if (pos1 == std::string::npos && pos2 == std::string::npos)
    namestart = 0;
  else if (pos1 == std::string::npos)
    namestart = pos2 + 1;
  else
    namestart = pos1 + 1;

  if (dotpos == std::string::npos || dotpos <= namestart || namestart > name.size())
    throw std::runtime_error("Error: Not a valid .bun pathname: " + name);

  return name.substr(namestart, dotpos - namestart);
}

int main(int argc, char** argv)
{
  for(int arg_i = 1; arg_i < argc; ++arg_i)
    {
      // count1 + 4 marks the end of the strings
      int count1;

      int entry_count;

      std::ifstream in(argv[arg_i], std::ios::binary);
      in.read(reinterpret_cast<char*>(&count1), sizeof(count1));
      in.read(reinterpret_cast<char*>(&entry_count), sizeof(entry_count));

      std::cout << "Count1: " << count1 << std::endl;
      std::cout << "Entry_Count: " << entry_count << std::endl;

      int total = 0; 
      for(int i = 0; i < entry_count; ++i)
        {
          std::string text; 
          char length = in.get(); // length of the string that follows

          int  ch;
          while((ch = in.get()) != 0)
            text += ch;

          std::cout << i << ") " << int(length) << " -> " << text.length() << ": " <<  text << std::endl;
          
          total += length + 2; // NULL and length byte in addition to string length + 
          text.clear();
        }

      std::cout << "Total: " << total << std::endl;
      std::cout << std::endl;

      {
        int count3;
        int count4;
        int count5;

        in.read(reinterpret_cast<char*>(&count3), sizeof(count3));
        std::cout << "Count3: " << count3 << std::endl;
        
        int counter3 = 0;
        while (counter3 < count3)
          {
            in.read(reinterpret_cast<char*>(&count4), sizeof(count4));
            in.read(reinterpret_cast<char*>(&count5), sizeof(count5));

            {
              std::vector<char> buffer(count5);
              in.read(reinterpret_cast<char*>(&*buffer.begin()), buffer.size());


              std::ostringstream filename;
              filename << "dirextract-out/" << directory_name_from_bun(argv[arg_i]) << "/" << count4 << "/" << counter3 << ".dat";

              std::cout << filename.str() << std::endl;
              
              if (1)
                {
                  create_hierachy(filename.str());

                  std::ofstream out(filename.str().c_str(), std::ios::binary);
                  out.write(reinterpret_cast<char*>(&*buffer.begin()), buffer.size());
                  out.close();
                }
            }

            //in.seekg(count5, std::ios::cur);
            
            std::cout << std::endl;
            std::cout << "Counter: " << counter3 << "/" << count3 << std::endl;
            std::cout << "block: " << count4 << std::endl;
            std::cout << "Size:  " << count5 << std::endl;

            counter3 += 1;

            //std::cout << "Div: " << count5 / count4 << std::endl;
          }

        if (0)
          {
            // count5 / count4 -> number of data?
            for(int i = 0; i < count5/64 ; ++i)
              {
                float vert[16];

                // vertex (3), uv (4), normal? (4)
                in.read(reinterpret_cast<char*>(vert), sizeof(vert));

                printf("%5d) ", i);
                for(unsigned int j = 0; j < sizeof(vert)/4; ++j)
                  printf(" %8.4f ",  vert[j]);
                putchar('\n');
              }
          }
      }
    }
}

/* EOF */
