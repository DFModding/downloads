/*  $Id: extract.cpp,v 1.1 2006/05/26 00:45:24 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#ifndef HEADER_EXTRACT_HPP
#define HEADER_EXTRACT_HPP

char nametable_encode(char c)
{
  c = tolower(c);
  // FIXME: Slow
  char table[] = "Xabcdefghijklmnopqrstuvwxyz/?-'_'.0123456789";
  
  for(size_t i = 0; i < sizeof(table); ++i)
    if (table[i] == c)
      return i;

  std::cerr << "\nERROR: '" << c << "' can't be encoded" << std::endl;
  return 1;
}

char nametable_decode(char c)
{
  static char table[] = "\0abcdefghijklmnopqrstuvwxyz/\?\?-_'.0123456789";
  
  if (size_t(c) < sizeof(table))
    {
      return table[int(c)];
    }
  else 
    {
      std::cerr << "\nERROR: " << int(c) << " out of table " << sizeof(table) << std::endl;
      return 'a';
    }
}

struct FileEntry
{
  int offset;
  int filesize;

  // Those could be analog to:
  // FileCount:    923
  // NumberCount:  371
  // ByteCount:   4598
  
  // if filesize is != 0 unknown1 is 0
  //                  range  : count
  int nametable_offset; // ~ 0-897  : 289 (like number1, reference to other file?)
  int path_length;      // ~ 0-85   : 78  (always ~100 range)
  int nametable_index;  // ~ 0-4585 : 427 (like number3)
  // Maybe one of those marks the directory?

  bool is_file() {
    return filesize != 0;
  }

  bool is_terminal() {
    return nametable_index == 0 && path_length == 0 && nametable_index == 0;
  }
};

struct TLJPak
{
  std::string filename;

  char magic[12];
  int  file_count;   // file entries
  int  number_count; // number of entries in the second and last section
  int  byte_count;   // a count that is similar to the last number in numbers
  
  std::vector<FileEntry> files;     // array of FileEntries with length file_count
  std::vector<char>      nametable; // array of bytes with length byte_count, values are never larger then 43
  std::vector<int>       indextable;   // array of int32 with length number_count

  TLJPak(const std::string& filename_)
    : filename(filename_)
  {
    std::ifstream in(filename.c_str(), std::ios::binary);
    if (!in)
      {
        throw std::runtime_error("Error: Couldn't open " + filename);
      }

    in.read(reinterpret_cast<char*>(&magic), 12);
    in.read(reinterpret_cast<char*>(&file_count), sizeof(int));
    in.read(reinterpret_cast<char*>(&number_count), sizeof(int));
    in.read(reinterpret_cast<char*>(&byte_count), sizeof(int));

    for(int i = 0; i < file_count; ++i)
      {
        FileEntry entry;
        int vals[5];

        in.read(reinterpret_cast<char*>(vals), sizeof(int)*5); 

        entry.offset           = vals[0];
        entry.filesize         = vals[1];
        entry.nametable_offset = vals[2];
        entry.path_length      = vals[3];
        entry.nametable_index  = vals[4];

        files.push_back(entry);
      }

    for(int i = 0; i < byte_count; ++i)
      {
        char character;
        in.read(reinterpret_cast<char*>(&character), sizeof(char));      
        nametable.push_back(nametable_decode(character));
      }

    for(int i = 0; i < number_count; ++i)
      {
        int number;
        in.read(reinterpret_cast<char*>(&number), sizeof(int));
        indextable.push_back(number);
      }   
  }

  std::string read_nametable(int offset)
  {
    std::string str;
    for(int i = 0; nametable[i] != '\0'; ++i)
      str += nametable[offset + i];
    return str;
  }

  int lookup(const char* pathname, int ptr, int i, int depth)
  {    
    if (depth > 20)
      return -1;
    
    if (i < 0 || i >= int(files.size()))
      {
        std::cerr << "Error: Lookup out of range " << std::endl;
        return -1;
      }

    if (files[i].filesize         == 0 &&
        files[i].path_length      == 0 &&
        files[i].nametable_offset == 0 &&
        files[i].nametable_index  == 0)
      {
        return -1;
      }
    else
      {
        assert(files[i].nametable_index >= 0 && files[i].nametable_index < int(nametable.size()));
        
        char* ntbl_entry     = &*nametable.begin() + files[i].nametable_index;
        int   ntbl_entry_len = strlen(ntbl_entry);

        if (0)
          {
            std::cout << ntbl_entry << " == ";
            std::cout.write(pathname+ptr+1, ntbl_entry_len);
            std::cout << std::endl;
          }

        if (strncmp(ntbl_entry, pathname+ptr+1, ntbl_entry_len) != 0)
          {
            return -1;
          }
        else
          {
            if (files[i].filesize != 0)
              { // Found a file
                //std::cout << files[i].path_length << std::endl;
                return i;
              }
            else
              {
                if (0)
                  {
                    std::cout << i << std::endl;
                    std::cout << "Offset:     " << files[i].offset << "\n"
                              << "Filesize:   " << files[i].filesize << "\n"
                              << "NTblOffset: " << files[i].nametable_offset << "\n"
                              << "PathLength: " << files[i].path_length << "\n"
                              << "NTblIndex:  " << files[i].nametable_index << std::endl;
        
                    std::cout << "Pathname:    " << pathname << " " << strlen(pathname) << std::endl;
                    std::cout << "PathPtr:     " << pathname + ptr << " " << strlen(pathname + ptr) << std::endl;
                    std::cout << "Path so far: "; std::cout.write(pathname, files[i].path_length+1); std::cout << std::endl;
                  }
                return lookup(pathname, ptr + ntbl_entry_len + 1, 
                              nametable_encode(pathname[files[i].path_length+1]) + files[i].nametable_offset, depth+1);
              }
          }
      }
  }

  std::vector<std::string> guess(int entry)
  {
    assert(entry >= 0);
    assert(entry < file_count);
    assert(files[entry].is_file());

    std::string pathname = &nametable[files[entry].nametable_index];
    std::vector<std::string> guesses;
    guess_lookup(entry, entry, pathname, files[entry].path_length, guesses);
    return guesses;
  }

  void guess()
  {
    for(int entry = 0; entry < file_count; ++entry)
      {
        if (files[entry].is_file()) 
          {
            std::vector<std::string> guesses;
  
            std::string pathname = &nametable[files[entry].nametable_index];
            guess_lookup(entry, entry, pathname, files[entry].path_length, guesses);

            //            if (guesses.size() == 1)
            //              std::cout << guesses[0] << std::endl;
            
            if (1)
              {
            for(int j = 0; j < int(guesses.size()); ++j)
              std::cout << entry << ") " << guesses[j] << std::endl;

            std::cout << std::endl;
              }
          }
      }
  }

  void guess_lookup(int orig_entry, int source_entry, const std::string& pathname, int path_length, 
                    std::vector<std::string>& guesses)
  {
    if (int(pathname.size()) + 1 == path_length)
      {
        //std::cout 
        //<< orig_entry << " "
        //<< nametable_decode(source_entry) << pathname << std::endl;
        guesses.push_back(nametable_decode(source_entry) + pathname);
      }
    else
      {
        for(int entry = 0; entry < file_count; ++entry)
          {
            if (!files[entry].is_file()) 
              {
                for(int j = 1; j < 43; ++j)
                  {
                    if (files[entry].nametable_offset + j == source_entry
                        && files[entry].path_length + int(pathname.length()) + 2 == path_length)
                      {
                        std::ostringstream str;
                        str << &nametable[files[entry].nametable_index] << nametable_decode(j) << pathname;
                        guess_lookup(orig_entry, entry, str.str(), path_length, guesses);
                      }
                  }
              }
          }
      }
  }

  /** Searches for \a pathname in the pack and returns the FileEntry
      that refers to the pathname */
  int lookup(std::string pathname)
  {
    for(unsigned int i = 0; i < pathname.size(); ++i)
      pathname[i] = tolower(pathname[i]);
    //std::cout << "Lookup: " << pathname << std::endl;
    int i = nametable_encode(pathname[0]);
    return lookup(pathname.c_str(), 0, i, 0);
  }

  void extract(int file_entry, const std::string& outfile)
  {
    assert(file_entry >= 0 && file_entry < int(files.size()));
    
    create_hierachy(outfile);

    if (files[file_entry].is_file())
      {
        std::ifstream in(filename.c_str(), std::ios::binary);
        if (!in)
          throw std::runtime_error("Error: Couldn't open " + filename);

        std::vector<char> filebuf;
        filebuf.resize(files[file_entry].filesize);
        in.seekg(files[file_entry].offset, std::ios::beg);
        in.read(reinterpret_cast<char*>(&*filebuf.begin()), filebuf.size());

        std::ofstream out(outfile.c_str());
        if (!out)
          throw std::runtime_error("Error: Couldn't open " + outfile);
        out.write(reinterpret_cast<char*>(&*filebuf.begin()), filebuf.size());
        out.close();

        in.close();
      }
  }

  void print_nametable()
  { 
    for(int i = 0; i < int(nametable.size()); ++i)
      {
        std::cout << i << ") ";
        while(nametable[i] != '\0' && i < int(nametable.size()))
          std::cout << nametable[i++];
        std::cout << std::endl;
      }
  }

  void print_indextable()
  {
    for(int i = 0; i < int(indextable.size()); ++i)
      std::cout << indextable[i] << std::endl;
  }

  void print_file_table()
  {
    if (1)
      {
        std::cout << "  Nr.     offset   filesize   NTblOffset  PathLength NTblIndex      Name" << std::endl;
        std::cout << "=================================================================================" << std::endl;
      }

    for(int i = 0; i < int(files.size()); ++i)
      printf("%4d) %10d %10d %10d %10d %10d        %s\n", 
             i,
             files[i].offset, 
             files[i].filesize,
             files[i].nametable_offset,
             files[i].path_length,
             files[i].nametable_index,
             (files[i].filesize + files[i].nametable_offset + files[i].path_length + files[i].nametable_index == 0)
             ? "(null)" : ("\"" + std::string(&nametable[files[i].nametable_index]) + "\"").c_str());
  }

  void print_info()
  {
    //std::cout << "Filename: " << filename << std::endl;
    //std::cout << "Filesize: " << st.st_size/1024/1024 << "mb (" << st.st_size << " nametable)" << std::endl;
    if (0)
      {
        std::cout << "Magic:         ";
        std::cout.write(magic, 12);
        std::cout << std::endl;

        std::cout << "File_Count:    " << file_count << std::endl;
        std::cout << "Number_Count:  " << number_count << std::endl;
        std::cout << "Nametable Count:   " << byte_count << std::endl;


        int sum = 0;
        for(int i = 0; i < int(files.size()); ++i)
          if (files[i].filesize != 0)
            sum += 1;
        std::cout << "Real Files:    " << sum << " (files with non-null filesize)" << std::endl;

        std::cout << std::endl;

        std::cout << "relative: " << indextable.back() << " < " << byte_count << std::flush;
        if (indextable.back() >= byte_count) std::cout << "!!!WRONG!!!" << std::endl; 
        else std::cout << std::endl;
    
      }
    print_nametable();
    print_file_table();
  }
};

#endif

/* EOF */
