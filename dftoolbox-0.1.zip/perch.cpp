/*  $Id: perch.cpp,v 1.1 2006/05/26 00:46:10 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <iomanip>
#include <ctype.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>

struct Value
{
  enum Type { STRING, TABLE, MAYBE, UNKNOWN };
  
  Type type;

  std::string value_string;
  typedef std::vector<std::pair<std::string, Value> > Table;
  Table* table;

  Value()
    : type(UNKNOWN), value_string("EMPTY")
  {
  }

  Value(const Table& table)
    : type(TABLE), table(new Table(table))
  {    
  }

  Value(Value::Type t, const std::string& str)
    : type(t), value_string(str)
  {
  }


  Value(const std::string& str) 
    : type(STRING), value_string(str)
  {
  }

};

typedef std::vector<std::pair<std::string, Value> > Table;

std::ostream& operator<<(std::ostream& os, const Value& value)
{
  switch (value.type)
    {
    case Value::STRING:
      os << '\'' << value.value_string << '\'' ;
      break;
      
    case Value::TABLE:
      os << "{" << std::endl;
      for(Table::const_iterator i = value.table->begin(); i != value.table->end(); ++i)
        os << "  " << i->first << " = " << i->second << std::endl;
      os << "}" << std::endl;
      break;

    case Value::MAYBE:
      os << "#<MAYBE: " << value.value_string << ">";
      break;

    case Value::UNKNOWN:
      os << "#<UNKNOWN: " << value.value_string << ">";
      break;

    default:
      os << "#<UNKNOWN>";
      break;
    }

  return os;
}

Table read_table(std::istream& in);

void read_zero(std::istream& in)
{
  int c = in.get();
  if (c != 0)
    std::cout << "Error: Expected 0x00 at: " << in.tellg() << " but got " << std::ios::hex << c << std::endl;
}

std::string read_string(std::istream& in)
{
  int c;
  std::string str;
  while ((c = in.get()) != -1 && c != '\0')
      str += c;
  return str;
}

std::string arr2hex(char* arr, int len)
{
  char hex[] = "0123456789ABCDEF";

  char  hexbuf[len * 3 + 1];
  char* hexbufptr = hexbuf;

  std::string str;

  for(int i = 0; i < len; ++i)
    {
      hexbuf[i*3+0] = hex[(arr[i]>>4) & 0x0F];
      hexbuf[i*3+1] = hex[arr[i] & 0x0F]; 
      hexbuf[i*3+2] = ' ';

      if (isprint(arr[i]))
        str += arr[i];
      else
        str += '.';
    }
  hexbufptr[len*3] = '\0';

  return std::string(hexbuf) + " | " + str;
}

Value read_value(std::istream& in)
{
  unsigned char type = in.get();
  switch(type)
    {
    case 0x01:
      {
        int a = in.get();
        int b = in.get();
        std::ostringstream str;
        str << " Integer or Bool (?): " << a << " " << b;
        return Value(Value::MAYBE, str.str());
      }
      break;

    case 0x08: // float
      {
        int len = in.get();
        std::ostringstream str("Floats: ");
        float v;
        for(int i = 0; i < len; ++i)
          {
            in.read(reinterpret_cast<char*>(&v), sizeof(v));
            str << v << " ";
          }
        read_zero(in);
        return Value(Value::MAYBE, str.str());
      }

      /*
    case 0x20: // Array of strings
      {
        // FIXME:
        exit (1);
      }
      break;
*/
    case 0x10: // string
      {
        int c = in.get();
        if (c == 0)
          {
            Value v(read_string(in));
            read_zero(in);
            return v;
          }
        else
          {
            std::ostringstream err;
            err << "Error: unknown string type: " << c;
            read_zero(in);
            return Value(Value::MAYBE, err.str());
          }
      }
      break;
      
    case 0x40: // table?
      {
        return Value(read_table(in));
      }

    default:
      {
        int offset = in.tellg();
        char arr[10];
        arr[0] = type;
        in.read(arr+1, 9);
        std::ostringstream err;
        err << "Error: unknown type " << std::hex << "0x" << int(type) << " discovered at 0x" 
            << std::hex << offset << "  |  " << arr2hex(arr, 10);
        return Value(Value::UNKNOWN, err.str());
      }
    }
}

Table 
read_table(std::istream& in)
{
  char globalcount;
  in.read(reinterpret_cast<char*>(&globalcount), sizeof(globalcount));
  
  char c1 = in.get();
  if (c1 != 0)
    { // FIXME: Not sure what those are good for
      while (in.get() != '\0');
      std::string name = read_string(in);
      std::cout << "Tablename: " << name << std::endl;
      read_zero(in);
    }

  Table globals;

  for(int i = 0; i < globalcount; ++i)
    {
      std::string name = read_string(in);
      Value value      = read_value(in);
      
      globals.push_back(std::pair<std::string, Value>(name, value));

      // Error out
      if (globals.back().second.type == Value::UNKNOWN)
        return globals;
    }

  return globals;
}

void print_table(Table table)
{
  for(Table::iterator i = table.begin(); i != table.end(); ++i)
    {
      std::cout << std::setw(13) << std::left << ("'" + i->first + "'") << " = " << i->second << std::endl;
    }
}

void
perch_view(const std::string& filename)
{
  std::ifstream in(filename.c_str(), std::ios::binary);

  std::string magic   = read_string(in);
  std::string version = read_string(in);

  if (magic != "shark3d_snake_binary" || version != "2x4")
    {
      std::cout << "Error: magic or version unknown: " << magic << " " << version << std::endl;
      return;
    }
  else
    {
      Table globals = read_table(in);
      print_table(globals);
    }

   in.close();
}

int main(int argc, char** argv)
{
  for(int i = 1; i < argc; ++i)
    {
      if (argc > 2)
        std::cout << "Filename: " << argv[i] << std::endl;

      perch_view(argv[i]);

      if (argc > 2)
        std::cout << std::endl;
    }
}

/* EOF */
