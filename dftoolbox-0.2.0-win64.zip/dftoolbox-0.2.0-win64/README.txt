DFToolBox 0.2.0
Inspect and modify the data files of the game Dreamfall.

Start dftoolbox.exe, or dfmodtool.exe to install mods. The dftool-*.exe
programs are command line tools.

Settings: %APPDATA%\dftoolbox\config\
Portable mode: create a file portable.txt next to dftoolbox.exe.

Licence: GPL-3.0-or-later (COPYING.txt).
Source: https://github.com/DFModding/dftoolbox
