/*  $Id: dialog.cpp,v 1.1 2006/05/26 00:45:41 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <vector>
#include <iostream>
#include <fstream>

#include "tinygettext.hpp"
#include "system.hpp"

// Dialog can be found in:
// c2d59212e9753be95c6ef8d425a9e14f  dreamfall-extractor/init/dat/0212.dat
// c2d59212e9753be95c6ef8d425a9e14f  dreamfall-extractor/laidback/dat/0003.dat


// 0x12: 14010 (number of text?)
// 0x1B5EA(112106): first text
// 0x1b5f8(112120): second text (14 distantce from 1.)
// 9564 lines of text in the file (index doing double refs -> yes, sort|uniq|wc gives exactly 9564)
// indexs: 0, 14, 19, ..., 580862, 580998
// number1 
// Double refs:
// 869 times: 56
// 1039 times: 85
// 287 times:  578
// longest string: 6508
struct TextEntry
{
  /** offset where the text starts, offset is relative to the first string */
  unsigned int   offset; 

  /** Range: 0 - 65535, widespread, 13263 different numbers */
  unsigned short number2;

  /** Range: 901 - 31372, very narrow, only 62 numbers used ->
      bitfield?! or NPC id, maybe reference to mp3 file or scripts/
      (~14874 there are, close to number2) or something else? */
  unsigned short number3;

  /** properties that might be encoded in number2 and number3:
      text color
      text size
      character id
      time the text is displayed
   */
};

struct Dialog
{
  std::string            lang_code;
  std::string            language;
  std::vector<TextEntry> entries;
  std::vector<char>      texts;

  void write(const std::string& outfile)
  {
    std::ofstream out(outfile.c_str(), std::ios::binary);
    unsigned int version = 2;


    out.write(reinterpret_cast<char*>(&version), sizeof(version));

    unsigned int language_len = language.size();   

    out.write(lang_code.c_str(), lang_code.size());
    out.write(reinterpret_cast<char*>(&language_len), sizeof(language_len));
    out.write(language.c_str(),  language.size());

    unsigned int entry_count = entries.size();
    out.write(reinterpret_cast<char*>(&entry_count), sizeof(entry_count));

    unsigned int blocksize = texts.size();
    out.write(reinterpret_cast<char*>(&blocksize), sizeof(blocksize));

    for(unsigned int i = 0; i < entries.size(); ++i)
      {
        TextEntry& entry = entries[i];

        out.write(reinterpret_cast<char*>(&entry.number2), sizeof(unsigned short));
        out.write(reinterpret_cast<char*>(&entry.number3), sizeof(unsigned short));
        out.write(reinterpret_cast<char*>(&entry.offset),  sizeof(unsigned int)); // regenerate this
      }

    out.write(&*texts.begin(), texts.size());

    out.close();
  }
};

std::string escape(const std::string& text)
{
  std::string res;
  for(std::string::size_type i = 0; i < text.length(); ++i)
    {
      if (text[i] == '"')
        res += "\\\"";
      else
        res += text[i];
    }
  return res;
}

void write_po2(const Dialog& dialog)
{
  std::string filename = get_cwd() + "dreamfall-" + dialog.lang_code + ".po";
  std::ofstream out(filename.c_str(), std::ios::binary);
  out << "# Dreamfall Dialog Extractor V0.0\n"
      << "msgid \"\"\n"
      << "msgstr \"\"\n"
      << "\"MIME-Version: 1.0\\n\"\n"
      << "\"Content-Type: text/plain; charset=UTF-8\\n\"\n"
      << "\"Content-Transfer-Encoding: 8bit\\n\"\n"
      << std::endl;        

  const char* texts = &*dialog.texts.begin();
  int   size  = dialog.texts.size();
  for(int i = 0; i < size; ++i)
    {
      out << "msgid \"" << escape(texts+i) << "\"" << std::endl;
      out << "msgstr \"\"\n" << std::endl;          
      
      i += strlen(texts+i);
    }

  //out << "\n# EOF #\n";
  out.close(); 
}

void write_po(const Dialog& dialog, const Dialog& dialog_en)
{
  bool use_en = true;
  if (dialog_en.entries.size() == 0)
    {
      use_en = false;
    }
  else
    {
      assert(dialog_en.entries.size() == dialog.entries.size());
    }

  std::string filename = get_cwd() + "dreamfall-" + dialog.lang_code + ".po";
  std::ofstream out(filename.c_str(), std::ios::binary);
  out << "# Dreamfall Dialog Extractor V0.0\n"
      << "msgid \"\"\n"
      << "msgstr \"\"\n"
      << "\"MIME-Version: 1.0\\n\"\n"
      << "\"Content-Type: text/plain; charset=UTF-8\\n\"\n"
      << "\"Content-Transfer-Encoding: 8bit\\n\"\n"
      << std::endl;        

  for(unsigned int i = 0; i < dialog.entries.size(); ++i)
    {
      if (use_en)
        {
          const TextEntry& entry    = dialog.entries[i];
          const TextEntry& entry_en = dialog_en.entries[i];
          
          out << "msgid \"" << escape(&*dialog_en.texts.begin() + entry_en.offset) << "\"" << std::endl;
          out << "msgstr \"" << escape(&*dialog.texts.begin() + entry.offset) << "\"\n" << std::endl;
        }
      else
        {
          const TextEntry& entry = dialog.entries[i];
          
          out << "msgid \"" << escape(&*dialog.texts.begin() + entry.offset) << "\"" << std::endl;
          out << "msgstr \"\"\n" << std::endl;          
        }
    }

  //out << "\n# EOF #\n";
  out.close();
}

void read_dialogs(const std::string& filename, std::vector<Dialog>& dialogs)
{
  // std::cout << "Processing: " << filename << std::endl;
  std::ifstream in(filename.c_str(), std::ios::binary);

  while (true)
    {
      Dialog dialog;

      unsigned int entry_count = 0;  
      unsigned int version = 0;
      in.read(reinterpret_cast<char*>(&version), sizeof(unsigned int));

      if (!in) // End of File found, no more translations available
        {
          std::cout << "End of file found: " << version << std::endl;
          break;
        }
      //std::cout << "." << std::endl;

      if (version == 0)
        { // english file
          in.seekg(0x12, std::ios::beg); 
          in.read(reinterpret_cast<char*>(&entry_count), sizeof(unsigned int));
          //std::cout << "EntryCount: " << entry_count << std::endl;

          unsigned int blocksize = 0;
          in.read(reinterpret_cast<char*>(&blocksize), sizeof(unsigned int));
          dialog.texts.resize(blocksize);
          dialog.lang_code = "en";
          dialog.language  = "English";
        }
      else if (version == 2)
        {
          dialog.lang_code += in.get();
          dialog.lang_code += in.get();

          unsigned int language_len = 0;
          in.read(reinterpret_cast<char*>(&language_len), sizeof(unsigned int));
      
          char language[language_len + 1];
          in.read(reinterpret_cast<char*>(&language), language_len);
          language[language_len] = '\0';
          dialog.language = language;

          //std::cout << "Code:     " << dialog.lang_code << std::endl;
          //std::cout << "Language: " << dialog.language  << std::endl;

          in.read(reinterpret_cast<char*>(&entry_count), sizeof(unsigned int));
          std::cout << "EntryCount: " << entry_count << std::endl;

          unsigned int blocksize = 0;
          in.read(reinterpret_cast<char*>(&blocksize), sizeof(unsigned int));
          dialog.texts.resize(blocksize);
        }
      else
        {
          std::cout << "Error: wrong version: " << version << std::endl;
          exit(EXIT_FAILURE);
        }

      for(unsigned int i = 0; in && (i < entry_count); ++i)
        {
          TextEntry entry;
          in.read(reinterpret_cast<char*>(&entry.number2), sizeof(unsigned short));
          in.read(reinterpret_cast<char*>(&entry.number3), sizeof(unsigned short));
          in.read(reinterpret_cast<char*>(&entry.offset), sizeof(unsigned int));

          // printf("%i: %10d %10d %10d\n", i, entry.offset, entry.number2, entry.number3);
          //printf("%10d\n", entry.number1);
          dialog.entries.push_back(entry);
        }

      in.read(&*dialog.texts.begin(), dialog.texts.size());

      if (0)
        { // debug print
          for(unsigned int i = 0; i < entry_count; ++i)
            {
              TextEntry& entry = dialog.entries[i];
              printf("%5i: %10d %10d %10d  \"%s\"\n", i, 
                     entry.offset, entry.number2, entry.number3, &*dialog.texts.begin() + entry.offset);
            }
        }

      dialogs.push_back(dialog);
    } // while(true)
  //std::cout << "EOF" << std::endl;
  in.close();
}


void extract(const char* filename)
{
  std::vector<Dialog> dialogs;
  read_dialogs(filename, dialogs);

  Dialog dialog_en;
  if (dialogs.size() == 1)
    {
      write_po2(dialogs.front());
    }
  else
    {
      for(std::vector<Dialog>::iterator i = dialogs.begin(); i != dialogs.end(); ++i)
        {
          if (i->lang_code == "en")
            {
              dialog_en = *i;
              //write_po(dialog_en, Dialog());
              write_po2(dialog_en);
            }
        }
  
      assert(dialog_en.entries.size() != 0);

      for(std::vector<Dialog>::iterator i = dialogs.begin(); i != dialogs.end(); ++i)
        {
          if (i->lang_code != "en")
            {
              write_po(*i, dialog_en);
            }
        }
    }
}

void generate(const std::string& localisation, const std::string& po_filename,
              const std::string& outfile)
{
  TinyGetText::Dictionary dictionary;
  std::ifstream po_in(po_filename.c_str());
  read_po_file(dictionary, po_in);
  
  std::vector<Dialog> dialogs;
  read_dialogs(localisation.c_str(), dialogs);

  Dialog dialog;
  for(std::vector<Dialog>::iterator i = dialogs.begin(); i != dialogs.end(); ++i)
    {
      if (i->lang_code == "en")
        {
          dialog = *i;
          break;
        }
    }

  Dialog new_dialog;
  new_dialog.lang_code = "nw";
  new_dialog.language  = "newlanguage";
  new_dialog.entries   = dialog.entries; 

  // Generate translation table
  typedef std::map<std::string, std::vector<int> > String2Entries;
  String2Entries string2entries;

  for(unsigned int i = 0; i < dialog.entries.size(); ++i)
    {
      string2entries[&*dialog.texts.begin() + dialog.entries[i].offset].push_back(i);
    }

  // write text entries and recalculate offsets
  const char* texts = &*dialog.texts.begin();
  int         size  = dialog.texts.size();
  for(int i = 0; i < size; ++i)
    {
      std::string trans = dictionary.translate(texts+i);
      
      // generate new offsets
      String2Entries::iterator e = string2entries.find(texts+i);
      if (e != string2entries.end())
        {
          for(std::vector<int>::iterator  j = e->second.begin(); j != e->second.end(); ++j)
            new_dialog.entries[*j].offset = new_dialog.texts.size();
        }
      else
        {
          std::cerr << "Error entry not found!" << std::endl;
        }

      // copy text entry to buffer
      for(unsigned int j = 0; j < trans.length(); ++j)
          new_dialog.texts.push_back(trans[j]);
      new_dialog.texts.push_back('\0');
      
      // advance
      i += strlen(texts+i);
    }

  std::cout << "Writing to " << outfile << std::endl;
  new_dialog.write(outfile);
}

int main(int argc, char** argv)
{
  if (argc == 1)
    {
      std::cout << "Dreamfall Dialog Extractor V0.1.1\n"
                << "=================================\n"
                << "\n"
                << "This program allows you to extract dialogs from Dreamfall.\n"
                << "To do so, first extract init.pak with the dreamfall-extractor.exe\n"
                << "and then extract the file init/dat/0212.dat with the dialog extractor\n"
                << "by drag&dropping it onto the dreamfall-dialog.exe. If you used a .pak\n"
                << "extractor that handles names, you find the dialog in the file:\n"
                << "data/generated/config/universe/localization.dat"
                << "\n"
                << "You should end up with a dreamfall-${LANG}.po in your current directory.\n"
                << "\n"
                << "For questions and comments mail Ingo Ruhnke <grumbel@gmx.de>\n"
                << "or join IRC, server irc.rizon.net, channel #Ragnar\n"
                << "\n"
                << "Full source code is available on request.\n"
                << std::endl;

      std::cout << "\nPress Enter to continue" << std::endl;
      getchar();
    }
  else if (strcmp(argv[1], "--generate") == 0)
    {
      if (argc == 4)
        {
          std::cout << "Generator mode" << std::endl;
          generate(argv[2], argv[3], "localisation-new.dat");
        }
      else
        {
          std::cout << "Usage: ./dialog --generate localization.dat dreamfall-$LANG.po" << std::endl;
        }
    }
  else
    {
      for(int i = 1; i < argc; ++i)
        {
          extract(argv[i]);
        }
    }
}

/* EOF */
