/*  $Id: shark3d.cpp,v 1.3 2006/05/27 19:01:42 ingo Exp $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>,
**                                 pinkunozou
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <map>

#include "util.hpp"
#include "shark3d.hpp"

namespace binary_parser {

int read_int(std::istream& in)
{
  int num = 0, c, shift = 0;
  do
    {
      c = in.get();
      num |= (c & 0x7f) << shift;
      shift += 7;
    } while (c >= 0x80);

  return num;
}

float read_float(std::istream& in)
{
  unsigned char byte[4];
  
  byte[3] = in.get();
  byte[2] = in.get();
  byte[1] = in.get();
  byte[0] = in.get();

  return *reinterpret_cast<float*>(byte);
}

std::string read_string_basic(std::istream& in)
{
  std::string str;
  int c;
  while((c = in.get()) != 0)
    str += c;
  return str;
}

std::string read_string(std::istream& in)
{
  int num = read_int(in);
  {
    int idx = directory.size() - num;
   
    if (directory.find(idx) != directory.end())
      {
        return directory[idx];
      }
    else
      {
        std::string ret = read_string_basic(in);
        directory[idx] = ret;
        return ret;
      }
  }
}

void read_section(std::istream& in, const std::string& prefix, std::ostream& out)
{
  int num = read_int(in);
  for(int i = 0; i < num; ++i)
    {
      std::string line = prefix + read_string(in);
      char code = in.get();
      switch(code)
        {
        case 0x0: // nil
          out << line << " {}" << std::endl;;
          break;

        case 0x1: // int
          out << line << " " << read_int(in) << std::endl;
          break;
          
        case 0x2: // int array
          {
            int n = read_int(in);
            out << line << " ";
            for(int j = 0; j < n; ++j)
              {
                out << read_int(in) << " ";
              }
            out << std::endl;;
          }
          break;

        case 0x4: // float
          out << line << " " << read_float(in) << std::endl;
          break;

        case 0x8: // float array
          {
            int n = read_int(in);
            out << line << " ";
            for (int j = 0; j < n; ++j)
              {
                out << read_float(in);
                if (j < n-1)
                  out << " ";
              }
            out << std::endl;
          }
          break;

        case 0x10: // string
          out << line << " \"" << read_string(in) << "\"" << std::endl;
          break;

        case 0x20: // string array
          {
            int n = read_int(in);
            out << line << std::endl;
            for(int j = 0; j < n; ++j)
              {
                out << prefix << "  \"" << read_string(in) << "\"" << std::endl;
              }
          }
          break;

        case 0x40: // section
          {
            out << line << std::endl;
            out << prefix << "{" << std::endl;
            read_section(in, prefix + "  ", out);
            out << prefix << "}" << std::endl;
          }
          break;

        case 0x80: // multi section
          {
            int n = read_int(in);
            out << line << std::endl;
            for(int j = 0; j < n; ++j)
              {
                out << prefix << "{" << std::endl;
                read_section(in, prefix + "  ", out);
                out << prefix << "}" << std::endl;
              }
          }
          break;

        default: 
          {
            std::ostringstream str;
            str << "Error: Unrecognized code: " << code << " " << out.tellp();
            throw std::runtime_error(str.str());
          }
          break;
        }
    }
}

SectionNode*
read_section(std::istream& in)
{
  SectionNode* section = new SectionNode();

  int num = read_int(in);
  for(int i = 0; i < num; ++i)
    {
      std::string name = read_string(in);
      char code = in.get();
      switch(code)
        {
        case 0x0: // nil
          section->add(name, new NullNode());
          break;

        case 0x1: // int
          section->add(name, new IntNode(read_int(in)));
          break;
          
        case 0x2: // int array
          {
            IntNode* int_node = new IntNode();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              int_node->ints.push_back(read_int(in));
            section->add(name, int_node);
          }
          break;

        case 0x4: // float
          section->add(name, new FloatNode(read_float(in)));
          break;

        case 0x8: // float array
          {
            FloatNode* float_node = new FloatNode();
            int n = read_int(in);
            for (int j = 0; j < n; ++j)
              float_node->floats.push_back(read_float(in));
            section->add(name, float_node);
          }
          break;

        case 0x10: // string
          section->add(name, new StringNode(read_string(in)));
          break;

        case 0x20: // string array
          {
            StringNode* string_node = new StringNode();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              string_node->strings.push_back(read_string(in));
            section->add(name, string_node);
          }
          break;

        case 0x40: // section
          section->add(name, new SectionNodes(read_section(in)));
          break;

        case 0x80: // multi section
          {
            SectionNodes* section_nodes = new SectionNodes();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              section_nodes->sections.push_back(read_section(in));
            section->add(name, section_nodes);
          }
          break;

        default: 
          {
            std::ostringstream str;
            str << "Error: Unrecognized code: 0x" << std::hex << int(code) << " " << in.tellg();
            throw std::runtime_error(str.str());
          }
          break;
        }
    }

  return section;
}

std::string perch2string(const std::string& filename)
{
  directory.clear();

  std::ifstream in(filename.c_str(), std::ios::binary);

  if(!in)
    {
      throw std::runtime_error("Error: Couldn't open '" + filename + "'");
    }
  else
    {
      std::ostringstream out;

      try {
        std::string magic   = read_string_basic(in);
        std::string version = read_string_basic(in);
        out << "# " << magic << " " << version << std::endl;
        //"# Automatically generated Shark 3D Snake 1x0 Text Stream. Format: ascii."
        if (0)
          {
            read_section(in, "", out);
          }
        else
          {
            SectionNode* node = read_section(in);
            node->print(out, "");
            delete node;
          }

        out << "$";
        in.close();
      } catch(...) {
        std::cout << out.str() << std::endl;
        throw;
      }
 
      return out.str();
    }
}
} // namespace binary_parser

namespace text_parser {

std::string read_string(std::istream& in)
{
  std::string ret;
  int c;

  // skip loading space
  while(isspace((c = in.get())));

  if (c == '#')
    { // skip comment
      while((c = in.get()) != '\n');
    }
  else
    {
      ret += c;
    }

  if (ret[0] == '"')
    {
      while((c = in.get()) != '"')
        ret += c;
      ret += '"';
      //ret = ret.substr(1);
    }
  else
    {
      while(!isspace((c = in.get())))
        ret += c;
    }

  return ret;
}

bool is_ident(const std::string& str)
{
  if (!isalpha(str[0]))
    return false;

  for(int i = 0; i < int(str.size()); ++i)
    if (!isalnum(str[i]) && str[i] != '_')
      return false;

  return true;
}

bool is_string(const std::string& str)
{
  return str[0] == '"' && str[str.size()-1] == '"';
}

bool is_int(const std::string& str)
{
  for(int i = 0; i < int(str.size()); ++i)
    if (!isdigit(str[i]) && str[i] != '-')
      return false;
  return true;
}

bool is_float(const std::string& str)
{
  for(int i = 0; i < int(str.size()); ++i)
    if (!isdigit(str[i]) && str[i] != '-' && str[i] != '+' && str[i] != 'e' && str[i] != '.')
      return false;
  return true; 
}

struct Token {
  enum Type { T_IDENT, T_STRING, T_INT, T_FLOAT, T_SECTION_START, T_SECTION_END, T_NULL, T_EOF };
  
  Type type;
  std::string value;

  Token(Type type_, const std::string& v) 
    : type(type_), value(v)
  {}

  int get_int() const
  {
    assert(type == T_INT);
    int v = 0; 
    assert(from_string(value, v));
    return v;
  }

  float get_float() const
  {
    assert(type == T_FLOAT);
    float v = 0; 
    assert(from_string(value, v));
    return v;
  }

  std::string get_string() const
  {
    if (type == T_STRING)
      return value.substr(1, value.size()-2);
    else if (type == T_IDENT)
      return value;
    else
      assert(false);
  }
};

std::vector<Token> tokenize(std::istream& in)
{
  std::vector<Token> tokens; 

  while(true)
    {
      std::string str = read_string(in);

      if (is_ident(str))
        {
          tokens.push_back(Token(Token::T_IDENT, str));
        }
      else if (is_int(str))
        {
          tokens.push_back(Token(Token::T_INT, str));
        }
      else if (is_float(str))
        {
          tokens.push_back(Token(Token::T_FLOAT, str));
        }
      else if (is_string(str))
        {
          tokens.push_back(Token(Token::T_STRING, str));
        }
      else if (str == "$")
        {
          tokens.push_back(Token(Token::T_EOF, str));
          break;
        }
      else if (str == "{")
        {
          tokens.push_back(Token(Token::T_SECTION_START, str));
        }
      else if (str == "}")
        {
          tokens.push_back(Token(Token::T_SECTION_END, str));
        }
      else if (str == "{}")
        {
          tokens.push_back(Token(Token::T_NULL, str));
        }
      else 
        {
          std::ostringstream out;
          out << "Error: Unknown token '" << str << "'";
          throw std::runtime_error(out.str());          
        }
    }
  return tokens;
}

SectionNode* parse(const std::vector<Token>& tokens, int& cur)
{
  SectionNode* section = new SectionNode();

  while(true)
    {
      // Get the ident
      std::string ident;
      if (tokens[cur].type == Token::T_IDENT)
        {
          ident = tokens[cur].get_string();
          cur += 1;
        }
      else if (tokens[cur].type == Token::T_SECTION_END ||
               tokens[cur].type == Token::T_EOF)
        {
          cur += 1;
          return section;
        }
      else
        {
          std::ostringstream str;
          str << "Error: Unexpected token, wanted indent, but got " << tokens[cur].type << "' " << tokens[cur].value << "'";
          throw std::runtime_error(str.str());
        }

      //std::cout << "Ident: " << ident << std::endl;

      // Get the value
      switch(tokens[cur].type)
        {
        case Token::T_STRING:
          {
            StringNode* node = new StringNode();
            while(tokens[cur].type == Token::T_STRING)
              {
                node->strings.push_back(tokens[cur].get_string());
                cur += 1;
              }
            section->add(ident, node);
          }
          break;
      
        case Token::T_INT:
          {
            IntNode* node = new IntNode();
            while(tokens[cur].type == Token::T_INT)
              {
                node->ints.push_back(tokens[cur].get_int());
                cur += 1;
              }
            section->add(ident, node);
          }
          break;

        case Token::T_FLOAT:
          {
            FloatNode* node = new FloatNode();
            while(tokens[cur].type == Token::T_FLOAT)
              {
                node->floats.push_back(tokens[cur].get_float());
                cur += 1;
              }
            section->add(ident, node);
          }
          break;

        case Token::T_NULL:
          section->add(ident, new NullNode());
          cur += 1;
          break;

          // Section Marker
        case Token::T_SECTION_START:
          {
            SectionNodes* node = new SectionNodes();
            while(tokens[cur].type == Token::T_SECTION_START)
              {
                node->sections.push_back(parse(tokens, ++cur));
              }
            section->add(ident, node);
          }
          break;

        default:
          std::ostringstream str;
          str << "Error: Unexpected token, wanted value got " << tokens[cur].type << "'" << tokens[cur].value << "'";
          throw std::runtime_error(str.str());
        }
    }  

  return section;
}

void perch2bin(const std::string& filename)
{
  std::ifstream in(filename.c_str());

  if(!in)
    {
      throw std::runtime_error("Error: Couldn't open '" + filename + "'");
    }
  else
    {
      const std::vector<Token>& tokens = tokenize(in);

      if (0)
        for(std::vector<Token>::const_iterator i = tokens.begin(); i != tokens.end(); ++i)
          {
            std::cout << i->type << " " << i->value << std::endl;
          }

      std::cout.write("shark3d_snake_binary", 21);
      std::cout.write("2x4", 4);

      int cur = 0;
      SectionNode* node = parse(tokens, cur);
      node->write(std::cout);
      delete node;      
    }
}

std::string perch2string(const std::string& filename)
{
  std::ifstream in(filename.c_str());

  if(!in)
    {
      throw std::runtime_error("Error: Couldn't open '" + filename + "'");
    }
  else
    {
      std::ostringstream out;
  
      const std::vector<Token>& tokens = tokenize(in);
      if (0)
        {
          for(std::vector<Token>::const_iterator i = tokens.begin(); i != tokens.end(); ++i)
            {
              std::cout << i->type << " " << i->value << std::endl;
            }
        }
  
      int cur = 0;
      SectionNode* node = parse(tokens, cur);
      node->print(out, "");
      out << "$";
      delete node;

      in.close();

      return out.str();
    }
}
} // namespace text_parser

int main(int argc, char** argv)
{
  if (argc == 1)
    {
      std::cout << "Usage: " << argv[0] << " FILENAME..." << std::endl;
    }
  else if (argc == 3 && strcmp(argv[1], "--compile") == 0)
    {
      //std::cout << text_parser::perch2string(argv[2]) << std::endl;
      text_parser::perch2bin(argv[2]);
    }
  else
    {
      for(int i = 1; i < argc; ++i)
        {
          try {
            if (argc > 2)
              std::cout << "Filename: " << argv[i] << std::endl;
      
            std::cout << binary_parser::perch2string(argv[i]) << std::endl;

            if (argc > 2)
              std::cout << std::endl;
          } catch(std::exception& err) {
            std::cout << err.what() << std::endl;
          }
        }
    }
}

/* EOF */
