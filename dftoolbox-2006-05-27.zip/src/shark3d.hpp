/*  $Id: shark3d.hpp,v 1.4 2006/05/27 19:17:56 ingo Exp $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#ifndef HEADER_SHARK3D_HPP
#define HEADER_SHARK3D_HPP

#include <iomanip>
#include <map>

// FIXME: int's might not be ints, but longs

std::map<int, std::string> directory;
std::map<std::string, int> directory2;

void write_int(std::ostream& out, int iv)
{
  unsigned int v = *reinterpret_cast<unsigned int*>(&iv);
  do { 
      if ((v & 0x7f) >= v)
        out.put((v & 0x7f));
      else
        out.put((v & 0x7f) | 0x80);
      v = v >> 7;
      //std::cerr << v << std::endl;
  }  while(v != 0);
}

void write_float(std::ostream& out, float v)
{
  char* buf = reinterpret_cast<char*>(&v);
  out.put(buf[3]);
  out.put(buf[2]);
  out.put(buf[1]);
  out.put(buf[0]);
}

void write_string(std::ostream& out, const std::string& str, bool use_dir = true)
{
  if (use_dir)
    {
      std::map<std::string, int>::iterator it = directory2.find(str);
      if (it == directory2.end())
        {
          directory2[str] = directory2.size();
          out.put(0);
          out.write(str.c_str(), str.size()+1);
        }
      else
        {
          write_int(out, directory2.size() - it->second + 1);
        }
    }
  else
    {
      out.put(0);
      out.write(str.c_str(), str.size()+1);
    }
}

class Node   { 
public: 
  virtual ~Node() {}
  virtual void print(std::ostream& out, const std::string& prefix) = 0;
  virtual void write(std::ostream& out) = 0;
};

class IntNode : public Node {
public:
  std::vector<int>  ints; 

  IntNode() {}
  IntNode(int i) { ints.push_back(i); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<int>::iterator i = ints.begin(); i != ints.end(); ++i)
      out << *i << " ";
  }

  void write(std::ostream& out)
  {
    assert(ints.size() > 0);
    if (ints.size() == 1) 
      {
        out.put(0x1);
        write_int(out, ints[0]);
      }
    else
      {
        out.put(0x2);
        write_int(out, ints.size());
        for(int i = 0; i < int(ints.size()); ++i)
          write_int(out, ints[i]);
      }
  }
};

class FloatNode : public Node { 
public:
  std::vector<float> floats;

  FloatNode() {};
  FloatNode(float f) { floats.push_back(f); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<float>::iterator i = floats.begin(); i != floats.end(); ++i)
      {  
        out.precision(26); // FIXME: not sure how much we need
        out << std::showpoint << *i << " ";
      }
  }

  void write(std::ostream& out) {
    assert(floats.size() > 0);
    if (floats.size() == 1) 
      {
        out.put(0x4);
        write_float(out, floats[0]);
      }
    else
      {
        out.put(0x8);
        write_int(out, floats.size());
        for(int i = 0; i < int(floats.size()); ++i)
          write_float(out, floats[i]);
      }
  }
};

class StringNode : public Node { 
public:
  std::vector<std::string> strings;

  StringNode() {}
  StringNode(const std::string& str) { strings.push_back(str); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<std::string>::iterator i = strings.begin(); i != strings.end(); ++i)
      out << "\"" << *i << "\" ";
  }

  void write(std::ostream& out)
  {
    assert(strings.size() > 0);
    if (strings.size() == 1) 
      {
        out.put(0x10);
        write_string(out, strings[0]);
      }
    else
      {
        out.put(0x20);
        write_int(out, strings.size());
        for(int i = 0; i < int(strings.size()); ++i)
          {
            write_string(out, strings[i]);
          }
      }
  }
};

class NullNode : public Node {
public:
  void print(std::ostream& out, const std::string& prefix) {
    out << "{}";
  }

  void write(std::ostream& out)
  {
    out.put(0);
  }
};

class SectionNode : public Node {
public:
  struct Entry {
    std::string name;
    Node* node;

    Entry(const std::string& name_, Node* node_) 
      : name(name_), node(node_)
    {}
  };

  typedef std::vector<Entry> Entries;
  Entries entries;

  SectionNode() {}
  ~SectionNode() {
    for(Entries::iterator i = entries.begin(); i != entries.end(); ++i)
      delete i->node;
  }

  void add(const std::string& name_, Node* node_) {
    entries.push_back(Entry(name_, node_));
  }

  void print(std::ostream& out, const std::string& prefix) {
    for(Entries::iterator i = entries.begin(); i != entries.end(); ++i)
      {
        out << prefix << i->name << ' ';
        i->node->print(out, prefix);
        out << std::endl;;
      }
  }

  void write(std::ostream& out)
  {
    //assert(entries.size() > 0);
    write_int(out, entries.size());
    for(Entries::iterator i = entries.begin(); i != entries.end(); ++i)
      {
        write_string(out, i->name);
        i->node->write(out);
      }
  }
};

class SectionNodes : public Node {
public: 
  std::vector<SectionNode*> sections; 

  SectionNodes() {}
  SectionNodes(SectionNode* node) { sections.push_back(node); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<SectionNode*>::size_type i = 0; i < sections.size(); ++i)
      {
        out << std::endl;
        out << prefix << "{" << std::endl;
        sections[i]->print(out, prefix + "   ");
        out << prefix << "}";
      }
  }

  void write(std::ostream& out)
  {
    assert(sections.size() > 0);
    if (sections.size() > 1)
      {
        out.put(0x80);
        write_int(out, sections.size());
      }
    else
      {
        out.put(0x40);
      }
    for(std::vector<SectionNode*>::size_type i = 0; i < sections.size(); ++i)
      {
        sections[i]->write(out);
      }
  }
};

#endif

/* EOF */
