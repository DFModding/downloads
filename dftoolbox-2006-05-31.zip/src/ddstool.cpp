#include <iostream>
#include <fstream>

#include "system.hpp"
#include "util.hpp"

#define DDPF_ALPHAPIXELS                0x00000001
#define DDPF_ALPHA                      0x00000002
#define DDPF_FOURCC                     0x00000004
#define DDPF_PALETTEINDEXED4            0x00000008
#define DDPF_PALETTEINDEXEDTO8          0x00000010
#define DDPF_PALETTEINDEXED8            0x00000020
#define DDPF_RGB                        0x00000040
#define DDPF_COMPRESSED                 0x00000080
#define DDPF_RGBTOYUV                   0x00000100
#define DDPF_YUV                        0x00000200
#define DDPF_ZBUFFER                    0x00000400
#define DDPF_PALETTEINDEXED1            0x00000800
#define DDPF_PALETTEINDEXED2            0x00001000
#define DDPF_ZPIXELS                    0x00002000
#define DDPF_STENCILBUFFER              0x00004000
#define DDPF_ALPHAPREMULT               0x00008000
#define DDPF_LUMINANCE                  0x00020000
#define DDPF_BUMPLUMINANCE              0x00040000
#define DDPF_BUMPDUDV                   0x00080000

class DDSCapabilities
{
public:
  // DDS files should always include DDSCAPS_TEXTURE. If the file
  // contains mipmaps, DDSCAPS_MIPMAP should be set. For any .dds file
  // with more than one main surface, such as a mipmaps, cubic
  // environment map, or volume texture, DDSCAPS_COMPLEX should also
  // be set.
  uint32_t dwCaps1;

  // For cubic environment maps, DDSCAPS2_CUBEMAP should be included
  // as well as one or more faces of the map
  // (DDSCAPS2_CUBEMAP_POSITIVEX, DDSCAPS2_CUBEMAP_NEGATIVEX,
  // DDSCAPS2_CUBEMAP_POSITIVEY, DDSCAPS2_CUBEMAP_NEGATIVEY,
  // DDSCAPS2_CUBEMAP_POSITIVEZ, DDSCAPS2_CUBEMAP_NEGATIVEZ). For
  // volume textures, DDSCAPS2_VOLUME should be included.
  uint32_t dwCaps2;

  DDSCapabilities()
  {
    dwCaps1 = 0;
    dwCaps2 = 0;
  }

  DDSCapabilities(std::istream& in)
  {
    dwCaps1 = read_uint32(in);
    dwCaps2 = read_uint32(in);
  }
};

class PixelFormat
{
public:
  // Size of structure. This member must be set to 32.
  uint32_t dwSize;

  // Flags to indicate valid fields. Uncompressed formats will usually
  // use DDPF_RGB to indicate an RGB format, while compressed formats
  // will use DDPF_FOURCC with a four-character code.
  uint32_t dwFlags;

  // This is the four-character code for compressed formats. dwFlags
  // should include DDPF_FOURCC in this case. For DXTn compression,
  // this is set to "DXT1", "DXT2", "DXT3", "DXT4", or "DXT5".
  uint32_t dwFourCC;

  // For RGB formats, this is the total number of bits in the
  // format. dwFlags should include DDPF_RGB in this case. This value
  // is usually 16, 24, or 32. For A8R8G8B8, this value would be 32.
  uint32_t dwRGBBitCount;
  
  // For RGB formats, these three fields contain the masks for the
  // red, green, and blue channels. For A8R8G8B8, these values would
  // be 0x00ff0000, 0x0000ff00, and 0x000000ff respectively.
  uint32_t dwRBitMask;
  uint32_t dwGBitMask;
  uint32_t dwBBitMask;
  
  // For RGB formats, this contains the mask for the alpha channel, if
  // any. dwFlags should include DDPF_ALPHAPIXELS in this case. For
  // A8R8G8B8, this value would be 0xff000000.
  uint32_t dwRGBAlphaBitMask;

  PixelFormat()
  {
  }

  PixelFormat(std::istream& in)
  {
    dwSize   = read_uint32(in);
    dwFlags  = read_uint32(in);
    dwFourCC = read_uint32(in);
    dwRGBBitCount = read_uint32(in);
    dwRBitMask = read_uint32(in);
    dwGBitMask = read_uint32(in);
    dwBBitMask = read_uint32(in);
    dwRGBAlphaBitMask = read_uint32(in);
  }
};

enum {
  DDS_DXT1 = 827611204,
  DDS_DXT2 = 844388420,
  DDS_DXT3 = 861165636,
  DDS_DXT4 = 877942852,
  DDS_DXT5 = 894720068
};

enum DDSFlags {
  DDSD_ALL          = 1047022,
  DDSD_ALPHABITDEPTH =    128,
  DDSD_BACKBUFFERCOUNT =   32,
  DDSD_CAPS         =       1,
  DDSD_CKDESTBLT    =   16384,
  DDSD_CKDESTOVERLAY =   8192,
  DDSD_CKSRCBLT     =   65536,
  DDSD_CKSRCOVERLAY =   32768,
  DDSD_HEIGHT       =       2,
  DDSD_LINEARSIZE   =  524288,
  DDSD_LPSURFACE    =    2048,
  DDSD_MIPMAPCOUNT  =  131072,
  DDSD_PITCH        =       8,
  DDSD_PIXELFORMAT  =    4096,
  DDSD_REFRESHRATE  =  262144,
  DDSD_TEXTURESTAGE = 1048576,
  DDSD_WIDTH        =       4,
  DDSD_ZBUFFERBITDEPTH =   64
};

class DDS
{
public:
  uint32_t magic;

  // Size of structure. This member must be set to 124.
  uint32_t dwSize; 

  // Flags to indicate valid fields. Always include DDSD_CAPS,
  // DDSD_PIXELFORMAT, DDSD_WIDTH, DDSD_HEIGHT.
  uint32_t flags;

  // Height of the main image in pixels
  uint32_t height;

  // Width of the main image in pixels
  uint32_t width;

  // For uncompressed formats, this is the number of bytes per scan
  // line (uint32_t> aligned) for the main image. dwFlags should include
  // DDSD_PITCH in this case. For compressed formats, this is the
  // total number of bytes for the main image. dwFlags should be
  // include DDSD_LINEARSIZE in this case.
  uint32_t dwPitchOrLinearSize;
  
  // For volume textures, this is the depth of the volume. dwFlags
  // should include DDSD_DEPTH in this case.
  uint32_t dwDepth;
  
  // For items with mipmap levels, this is the total number of levels
  // in the mipmap chain of the main image. dwFlags should include
  // DDSD_MIPMAPCOUNT in this case.
  uint32_t dwMipMapCount;

  // Unused	
  uint32_t dwReserved1[11];

  // 32-byte value that specifies the pixel format structure.
  PixelFormat pixel_format;
  
  // 16-byte value that specifies the capabilities structure.
  DDSCapabilities ddsCaps;

  // Unused
  uint32_t dwReserved2;

  std::vector<char> data;
  
  DDS(std::istream& in) {
    magic  = read_uint32(in);
    dwSize = read_uint32(in);
    flags  = read_uint32(in);
    height = read_uint32(in);
    width  = read_uint32(in);
    dwPitchOrLinearSize = read_uint32(in);
    dwDepth = read_uint32(in);
    dwMipMapCount = read_uint32(in);
    
    for(int i = 0; i < 11; ++i)
      dwReserved1[i] = read_uint32(in);

    pixel_format = PixelFormat(in);

    ddsCaps = DDSCapabilities(in);

    dwReserved2 = read_uint32(in);
    
    // Read pixel data
    if (flags & DDPF_FOURCC)
      {
        switch (pixel_format.dwFourCC)
          {
          case DDS_DXT1:
            for(uint32_t y = 0; y < height; ++y)
              for(uint32_t x = 0; x < width; ++x)
                {
                  //colors = read_uint32(in);
                  
                  //uint32_t color[4];

                  //color[0] = colors &

                  //data.push_back();
                }
            break;

          case DDS_DXT2:
            break;

          case DDS_DXT3:
            break;
            
          case DDS_DXT4:
            break;

          case DDS_DXT5:
            break;
          }
      }
  }
};

int main(int argc, char** argv)
{
  for(int i = 1; i < argc; ++i)
    {
      std::ifstream in(argv[i], std::ios::binary);
      if(!in)
        {
          std::cout << "Error: Couldn't open " << argv[i] << std::endl;
        }
      else
        {
          DDS dds(in);
          
          std::cout << "Filename:      " << argv[i] << std::endl;
          std::cout << "Size:          " << dds.width << "x" << dds.height << std::endl;
          std::cout << "Flags:         " << dds.flags << std::endl;
          std::cout << "Pitch:         " << dds.dwPitchOrLinearSize << std::endl;
          std::cout << "Depth:         " << dds.dwDepth << std::endl;
          std::cout << "MipmapCount:   " << dds.dwMipMapCount << std::endl;
          std::cout << "PixFmt.FourCC: " << std::string((char*)(&dds.pixel_format.dwFourCC), 4) << " " << dds.pixel_format.dwFourCC << std::endl;
          std::cout << "PixFmt.Bits:   " << dds.pixel_format.dwRGBBitCount << std::endl;
          std::cout << "PixFmt.RMask   " << dds.pixel_format.dwRBitMask << std::endl;
          std::cout << "PixFmt.BMask   " << dds.pixel_format.dwBBitMask << std::endl;
          std::cout << "PixFmt.GMask   " << dds.pixel_format.dwGBitMask << std::endl;
          std::cout << "PixFmt.AMask   " << dds.pixel_format.dwRGBAlphaBitMask << std::endl;
          std::cout << std::endl;
        }
    } 
}

/* EOF */
