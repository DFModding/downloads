/*  $Id: shark3d.cpp,v 1.1 2006/05/26 22:49:44 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <string>
#include <sstream>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <map>

#include "shark3d.hpp"

std::map<int, std::string> directory;
int string_count;


int read_int(std::istream& in)
{
  int num = 0, c, shift = 0;
  do
    {
      c = in.get();
      num |= (c & 0x7f) << shift;
      shift += 7;
    } while (c >= 0x80);

  return num;
}

float read_float(std::istream& in)
{
  float num;
  in.read(reinterpret_cast<char*>(&num), sizeof(num));
  return num;
}

std::string read_string_basic(std::istream& in)
{
  std::string str;
  int c;
  while((c = in.get()) != 0)
    str += c;
  return str;
}

std::string read_string(std::istream& in)
{
  int num = read_int(in);
  {
    int idx = string_count - num;
    if (num == 0)
      string_count++;
    
    if (directory.find(idx) != directory.end())
      {
        return directory[idx];
      }
    else
      {
        std::string ret = read_string_basic(in);
        directory[idx] = ret;
        return ret;
      }
  }
}

void read_section(std::istream& in, const std::string& prefix, std::ostream& out)
{
  int num = read_int(in);
  for(int i = 0; i < num; ++i)
    {
      std::string line = prefix + read_string(in);
      char code = in.get();
      switch(code)
        {
        case 0x0: // nil
          out << line << " {}" << std::endl;;
          break;

        case 0x1: // int
          out << line << " " << read_int(in) << std::endl;
          break;
          
        case 0x2: // int array
          {
            int n = read_int(in);
            out << line << " ";
            for(int j = 0; j < n; ++j)
              {
                out << read_int(in) << " ";
              }
            out << std::endl;;
          }
          break;

        case 0x4: // float
          out << line << " " << read_float(in) << std::endl;
          break;

        case 0x8: // float array
          {
            int n = read_int(in);
            out << line << " ";
            for (int j = 0; j < n; ++j)
              {
                out << read_float(in);
                if (j < n-1)
                  out << " ";
              }
            out << std::endl;
          }
          break;

        case 0x10: // string
          out << line << " \"" << read_string(in) << "\"" << std::endl;
          break;

        case 0x20: // string array
          {
            int n = read_int(in);
            out << line << std::endl;
            for(int j = 0; j < n; ++j)
              {
                out << prefix << "  \"" << read_string(in) << "\"" << std::endl;
              }
          }
          break;

        case 0x40: // section
          {
            out << line << std::endl;
            out << prefix << "{" << std::endl;
            read_section(in, prefix + "  ", out);
            out << prefix << "}" << std::endl;
          }
          break;

        case 0x80: // multi section
          {
            int n = read_int(in);
            out << line << std::endl;
            for(int j = 0; j < n; ++j)
              {
                out << prefix << "{" << std::endl;
                read_section(in, prefix + "  ", out);
                out << prefix << "}" << std::endl;
              }
          }
          break;

        default: 
          {
            std::ostringstream str;
            str << "Error: Unrecognized code: " << code;
            throw std::runtime_error(str.str());
          }
          break;
        }
    }
}

SectionNode*
read_section(std::istream& in)
{
  SectionNode* section = new SectionNode();

  int num = read_int(in);
  for(int i = 0; i < num; ++i)
    {
      std::string name = read_string(in);
      char code = in.get();
      switch(code)
        {
        case 0x0: // nil
          section->add(name, new NullNode());
          break;

        case 0x1: // int
          section->add(name, new IntNode(read_int(in)));
          break;
          
        case 0x2: // int array
          {
            IntNode* int_node = new IntNode();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              int_node->ints.push_back(read_int(in));
            section->add(name, int_node);
          }
          break;

        case 0x4: // float
          section->add(name, new FloatNode(read_float(in)));
          break;

        case 0x8: // float array
          {
            FloatNode* float_node = new FloatNode();
            int n = read_int(in);
            for (int j = 0; j < n; ++j)
              float_node->floats.push_back(read_float(in));
            section->add(name, float_node);
          }
          break;

        case 0x10: // string
          section->add(name, new StringNode(read_string(in)));
          break;

        case 0x20: // string array
          {
            StringNode* string_node = new StringNode();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              string_node->strings.push_back(read_string(in));
            section->add(name, string_node);
          }
          break;

        case 0x40: // section
          section->add(name, new SectionNodes(read_section(in)));
          break;

        case 0x80: // multi section
          {
            SectionNodes* section_nodes = new SectionNodes();
            int n = read_int(in);
            for(int j = 0; j < n; ++j)
              section_nodes->sections.push_back(read_section(in));
            section->add(name, section_nodes);
          }
          break;

        default: 
          {
            std::ostringstream str;
            str << "Error: Unrecognized code: " << code;
            throw std::runtime_error(str.str());
          }
          break;
        }
    }

  return section;
}

std::string perch2string(const std::string& filename)
{
  directory.clear();
  string_count = 0;

  std::ifstream in(filename.c_str(), std::ios::binary);
  std::ostringstream out;

  try {
    std::string magic   = read_string_basic(in);
    std::string version = read_string_basic(in);
    out << "# " << magic << " " << version << std::endl;
    //"# Automatically generated Shark 3D Snake 1x0 Text Stream. Format: ascii."
    if (0)
      {
        read_section(in, "", out);
      }
    else
      {
        SectionNode* node = read_section(in);
        node->print(out, "");
        delete node;
      }

    out << "$";
    in.close();
  } catch(...) {
    std::cout << out.str() << std::endl;
    throw;
  }
 
  return out.str();
}

int main(int argc, char** argv)
{
  if (argc == 1)
    {
      std::cout << "Usage: " << argv[0] << " FILENAME..." << std::endl;
    }
  else
    {
      for(int i = 1; i < argc; ++i)
        {
          try {
            if (argc > 2)
              std::cout << "Filename: " << argv[i] << std::endl;
      
            std::cout << perch2string(argv[i]) << std::endl;

            if (argc > 2)
              std::cout << std::endl;
          } catch(std::exception& err) {
            std::cout << err.what() << std::endl;
          }
        }
    }
}

/* EOF */
