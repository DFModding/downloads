/*  $Id: perch.cpp,v 1.1 2006/05/26 00:46:10 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#ifndef HEADER_SHARK3D_HPP
#define HEADER_SHARK3D_HPP

class Node   { 
public: 
  virtual ~Node() {}
  virtual void print(std::ostream& out, const std::string& prefix) = 0;
};

class IntNode : public Node {
public:
  std::vector<int>  ints; 

  IntNode() {}
  IntNode(int i) { ints.push_back(i); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<int>::iterator i = ints.begin(); i != ints.end(); ++i)
      out << *i << " ";
  }
};

class FloatNode : public Node { 
public:
  std::vector<float> floats;

  FloatNode() {};
  FloatNode(float f) { floats.push_back(f); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<float>::iterator i = floats.begin(); i != floats.end(); ++i)
      out << *i << " ";
  }
};

class StringNode : public Node { 
public:
  std::vector<std::string> strings;

  StringNode() {}
  StringNode(const std::string& str) { strings.push_back(str); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<std::string>::iterator i = strings.begin(); i != strings.end(); ++i)
      out << "\"" << *i << "\" ";
  }
};

class NullNode : public Node {
public:
  void print(std::ostream& out, const std::string& prefix) {
    out << "{}";
  }
};

class SectionNode : public Node {
public:
  struct Entry {
    std::string name;
    Node* node;

    Entry(const std::string& name_, Node* node_) 
      : name(name_), node(node_)
    {}
  };

  typedef std::vector<Entry> Entries;
  Entries entries;

  SectionNode() {}
  ~SectionNode() {
    for(Entries::iterator i = entries.begin(); i != entries.end(); ++i)
      delete i->node;
  }

  void add(const std::string& name_, Node* node_) {
    entries.push_back(Entry(name_, node_));
  }

  void print(std::ostream& out, const std::string& prefix) {
    for(Entries::iterator i = entries.begin(); i != entries.end(); ++i)
      {
        out << prefix << i->name << ' ';
        i->node->print(out, prefix);
        out << std::endl;;
      }
  }
};

class SectionNodes : public Node {
public: 
  std::vector<SectionNode*> sections; 

  SectionNodes() {}
  SectionNodes(SectionNode* node) { sections.push_back(node); }

  void print(std::ostream& out, const std::string& prefix) {
    for(std::vector<SectionNode*>::size_type i = 0; i < sections.size(); ++i)
      {
        out << std::endl;
        out << prefix << "{" << std::endl;
        sections[i]->print(out, prefix + "   ");
        out << prefix << "}";
      }
  }
};

#endif

/* EOF */
