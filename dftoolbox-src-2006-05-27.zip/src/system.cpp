/*  $Id: system.cpp,v 1.1 2006/05/26 00:46:22 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#ifdef __linux__
#  include <sys/stat.h>
#  include <sys/types.h>
#else
#  include <windows.h>
#  include <direct.h>
#endif

#include <iostream>
#include "system.hpp"

std::string get_cwd()
{
#ifdef __linux__
  return "./";
#else
  // Get path to executable:
  char szDllName[_MAX_PATH];
  char szDrive[_MAX_DRIVE];
  char szDir[_MAX_DIR];
  char szFilename[_MAX_FNAME];
  char szExt[_MAX_EXT];
  GetModuleFileName(0, szDllName, _MAX_PATH);
  _splitpath(szDllName, szDrive, szDir, szFilename, szExt);

  return std::string(szDrive) + std::string(szDir);
#endif
}

void create_hierachy(const std::string& outfile)
{
  for(std::string::size_type i = 0; i < outfile.size(); ++i)
    {
      if (outfile[i] == '/')
        {
          std::string dir = outfile.substr(0, i);
          //std::cout << "Create Dir: " << dir << std::endl;
          create_dir(dir);
        }
    }
}

int create_dir(const std::string& path)
{
#ifdef __linux__
  return mkdir(path.c_str(), 0755);
#else
  return _mkdir(path.c_str());
#endif
}

void wait()
{
#ifndef __linux__
  // Wait for a keypress so that the user can look at the textual
  // output in Windows
  std::cout << "\nPress Enter to continue..." << std::endl;
  getchar();
#endif
}

/* EOF */

