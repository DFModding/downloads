/*  $Id: extract.cpp,v 1.1 2006/05/26 00:45:24 ingo Exp ingo $
**  ___  ___ _____         _ ___
** |   \| __|_   _|__  ___| | _ ) _____ __
** | |) | _|  | |/ _ \/ _ \ | _ \/ _ \ \ /
** |___/|_|   |_|\___/\___/_|___/\___/_\_\
**
**  DFToolBox - Copyright (C) 2006 Ingo Ruhnke <grumbel@gmx.de>
**
**  This program is free software; you can redistribute it and/or
**  modify it under the terms of the GNU General Public License
**  as published by the Free Software Foundation; either version 2
**  of the License, or (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
** 
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
**  02111-1307, USA.
*/

#include <iomanip>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include "system.hpp"
#include "tljpak.hpp"

char nametable_encode(char c)
{
  c = tolower(c);
  // FIXME: Slow
  char table[] = "Xabcdefghijklmnopqrstuvwxyz/?-'_'.0123456789";
  
  for(size_t i = 0; i < sizeof(table); ++i)
    if (table[i] == c)
      return i;

  std::cerr << "\nERROR: '" << c << "' can't be encoded" << std::endl;
  return 1;
}

char nametable_decode(char c)
{
  static char table[] = "\0abcdefghijklmnopqrstuvwxyz/\?\?-_'.0123456789";
  
  if (size_t(c) < sizeof(table))
    {
      return table[int(c)];
    }
  else 
    {
      std::cerr << "\nERROR: " << int(c) << " out of table " << sizeof(table) << std::endl;
      return 'a';
    }
}


TLJPak::TLJPak(const std::string& filename_)
  : filename(filename_)
{
  std::ifstream in(filename.c_str(), std::ios::binary);
  if (!in)
    {
      throw std::runtime_error("Error: Couldn't open " + filename);
    }

  in.read(reinterpret_cast<char*>(&magic), 12);
  in.read(reinterpret_cast<char*>(&file_count), sizeof(int));
  in.read(reinterpret_cast<char*>(&number_count), sizeof(int));
  in.read(reinterpret_cast<char*>(&byte_count), sizeof(int));

  for(int i = 0; i < file_count; ++i)
    {
      FileEntry entry;
      int vals[5];

      in.read(reinterpret_cast<char*>(vals), sizeof(int)*5); 

      entry.offset           = vals[0];
      entry.filesize         = vals[1];
      entry.nametable_offset = vals[2];
      entry.path_length      = vals[3];
      entry.nametable_index  = vals[4];

      files.push_back(entry);
    }

  for(int i = 0; i < byte_count; ++i)
    {
      char character;
      in.read(reinterpret_cast<char*>(&character), sizeof(char));      
      nametable.push_back(nametable_decode(character));
    }

  for(int i = 0; i < number_count; ++i)
    {
      int number;
      in.read(reinterpret_cast<char*>(&number), sizeof(int));
      indextable.push_back(number);
    }   
}

void
TLJPak::generate_filetable()
{
  std::cout << "generate_filetable()" << std::endl;

  int pos = 
    12 + 4 + 4 + 4 +       // Header
    files.size() * 4 * 5 + // Filetable
    nametable.size() +     // Nametable
    indextable.size()*4    // Indextable
    ;

  header_padding = pos;

  // Round pos up to a multiple of 2048, not sure if its needed, but
  // thats how the original .paks look like
  if ((pos % 2048) != 0)
    pos = ((pos / 2048) + 1) * 2048; 

  header_padding = pos - header_padding;

  std::cout << "Start Pos: " << pos << std::endl;

  std::vector<ChunkDesc> chunk_descs;
  for(int i = 0; i < int(chunks.size()); ++i)
    {
      chunk_descs.push_back(ChunkDesc(pos, chunks[i].size()));
      pos += chunks[i].size();
    }

  for(int i = 0; i < file_count; ++i)
    {
      assert(files[i].chunk_id != -1);
      files[i].offset = chunk_descs[files[i].chunk_id].offset;
      
      if (files[i].filesize != 0)
        files[i].filesize = chunk_descs[files[i].chunk_id].size;
    }
}

void
TLJPak::write(const std::string& outfile)
{
  if (chunks.size() == 0)
    read_chunks();

  assert(chunks.size() > 0);

  generate_filetable();

  std::ofstream out(outfile.c_str(), std::ios::binary);

  out.write(magic, 12);
  out.write(reinterpret_cast<char*>(&file_count),   sizeof(int));
  out.write(reinterpret_cast<char*>(&number_count), sizeof(int));
  out.write(reinterpret_cast<char*>(&byte_count),   sizeof(int));

  // write file index table
  for(int i = 0; i < file_count; ++i)
    {
      out.write(reinterpret_cast<char*>(&files[i].offset),           sizeof(int)); 
      out.write(reinterpret_cast<char*>(&files[i].filesize),         sizeof(int)); 
      out.write(reinterpret_cast<char*>(&files[i].nametable_offset), sizeof(int)); 
      out.write(reinterpret_cast<char*>(&files[i].path_length),      sizeof(int)); 
      out.write(reinterpret_cast<char*>(&files[i].nametable_index),  sizeof(int)); 
    }

  // write byte block
  for(int i = 0; i < int(nametable.size()); ++i)
    {
      // FIXME: Encode this
      out.write(reinterpret_cast<char*>(&nametable[i]), sizeof(char));
    }

  // write number block
  for(int i = 0; i < int(indextable.size()); ++i)
    {
      out.write(reinterpret_cast<char*>(&indextable[i]), sizeof(int));
    }

  std::cout << "Header padding: " << header_padding << std::endl;
  for(int i = 0; i < header_padding; ++i)
    out.put(0);

  for(int i = 0; i < int(chunks.size()); ++i)
    {
      out.write(reinterpret_cast<char*>(&*chunks[i].begin()), chunks[i].size());
    }

  { // fill in padding bytes at the end of file to reach a total
    // filesize of a multiple of 131072, not sure if these are
    // needed, but we do so to have exactly the same file structure
    // like in the original paks
    out.seekp(0, std::ios::end);
    int end = out.tellp();

    if ((end % 131072) != 0)
      {
        for(int i = 0; i < 131072 - (end % 131072); ++i)
          out.put(0xae);
      }
  } 

  out.close();
}

struct ChunkSort
{
  bool operator()(const ChunkDesc& a, const ChunkDesc& b)
  {
    return a.offset < b.offset;
  }
};

std::vector<ChunkDesc>
TLJPak::collect_chunk_desc()
{
  std::vector<ChunkDesc> firstsweep;

  // Collect chunks
  for(int i = 0; i < int(files.size()); ++i)
    {
      if (files[i].is_file())
        firstsweep.push_back(ChunkDesc(files[i].offset, files[i].filesize));
    }

  std::sort(firstsweep.begin(), firstsweep.end(), ChunkSort());

  std::vector<ChunkDesc> chunk_lst;

  for(int i = 0; i < int(firstsweep.size()); ++i)
    {
      if (chunk_lst.size() == 0 || chunk_lst.back() != firstsweep[i])
        {
          chunk_lst.push_back(firstsweep[i]);
        }
    }

  assert(chunk_lst.size() > 0);
  // Check for holes
  for(int i = 1; i < int(chunk_lst.size()); ++i)
    { // files themself are '0' padded as well!

      //std::cout << chunk_lst[i].offset << std::endl;
      if (chunk_lst[i].offset != (chunk_lst[i-1].offset + chunk_lst[i-1].size))
        {
          chunk_lst[i].padding = chunk_lst[i].offset - (chunk_lst[i-1].offset + chunk_lst[i-1].size);

          std::cout << "Hole in file: got "
                    << chunk_lst[i].offset
                    << " expected " << chunk_lst[i-1].offset + chunk_lst[i-1].size 
                    << " distance "
                    << chunk_lst[i].padding
                    << std::endl;
        }
    }

  return chunk_lst;
}

void
TLJPak::read_chunks()
{
  std::cout << "read_chunks()" << std::endl;
  const std::vector<ChunkDesc>& chunk_descs = collect_chunk_desc();

  std::cout << std::setw(10) << "Offset" 
            << std::setw(10) << "Size"
            << std::setw(10) << "Padding"
            << std::endl;
  for(int i = 0; i < int(chunk_descs.size()); ++i)
    {
      std::cout << std::setw(10) << chunk_descs[i].offset   << " " 
                << std::setw(10) << chunk_descs[i].size     << " "
                << std::setw(10) << chunk_descs[i].padding  << " "
                << std::endl;
    }

  // Write chunk ids into the filetable
  for(int i = 0; i < int(chunk_descs.size()); ++i)
    { // FIXME: A little slow, could use map to optimize
      for(int j = 0; j < int(files.size()); ++j)
        {
          if (files[j].offset == chunk_descs[i].offset)
            {
              if (files[j].filesize == 0 || files[j].filesize == chunk_descs[i].size )
                {
                  files[j].chunk_id = i;
                }
              else
                {
                  std::ostringstream str;
                  str << "Error: Inconsistent File table at: " 
                      << files[j].offset << ":" << files[j].filesize
                      << " vs " 
                      << chunk_descs[i].offset << ":" << chunk_descs[i].size;
                  throw std::runtime_error(str.str());
                }
            }
        }
    }

  // inconsistentcy check to make sure that all chunk_ids are != -1
  for(int i = 0; i < int(files.size()); ++i)
    {
      if (files[i].chunk_id == -1)
        {
          throw std::runtime_error("Error: Inconsistentcy file table, entry not mapped to chunk");
        }
    }

  
  std::ifstream in(filename.c_str(), std::ios::binary);
  if (!in)
    {
      throw std::runtime_error("Error: Couldn't open " + filename);
    }

  chunks.resize(chunk_descs.size());
  for(int i = 0; i < int(chunk_descs.size()); ++i)  
    {
      std::vector<char>& chunk = chunks[i];
      chunk.resize(chunk_descs[i].size + chunk_descs[i].padding, 0);

      in.seekg(chunk_descs[i].offset, std::ios::beg);
      in.read(reinterpret_cast<char*>(&*chunk.begin()), chunk_descs[i].size);
    }

  in.close();
}

std::string
TLJPak::read_nametable(int offset)
{
  std::string str;
  for(int i = 0; nametable[i] != '\0'; ++i)
    str += nametable[offset + i];
  return str;
}

int
TLJPak::lookup(const char* pathname, int ptr, int i, int depth)
{    
  if (depth > 20)
    return -1;
    
  if (i < 0 || i >= int(files.size()))
    {
      std::cerr << "Error: Lookup out of range " << std::endl;
      return -1;
    }

  if (files[i].filesize         == 0 &&
      files[i].path_length      == 0 &&
      files[i].nametable_offset == 0 &&
      files[i].nametable_index  == 0)
    {
      return -1;
    }
  else
    {
      assert(files[i].nametable_index >= 0 && files[i].nametable_index < int(nametable.size()));
        
      char* ntbl_entry     = &*nametable.begin() + files[i].nametable_index;
      int   ntbl_entry_len = strlen(ntbl_entry);

      if (0)
        {
          std::cout << ntbl_entry << " == ";
          std::cout.write(pathname+ptr+1, ntbl_entry_len);
          std::cout << std::endl;
        }

      if (strncmp(ntbl_entry, pathname+ptr+1, ntbl_entry_len) != 0)
        {
          return -1;
        }
      else
        {
          if (files[i].filesize != 0)
            { // Found a file
              //std::cout << files[i].path_length << std::endl;
              return i;
            }
          else
            {
              if (0)
                {
                  std::cout << i << std::endl;
                  std::cout << "Offset:     " << files[i].offset << "\n"
                            << "Filesize:   " << files[i].filesize << "\n"
                            << "NTblOffset: " << files[i].nametable_offset << "\n"
                            << "PathLength: " << files[i].path_length << "\n"
                            << "NTblIndex:  " << files[i].nametable_index << std::endl;
        
                  std::cout << "Pathname:    " << pathname << " " << strlen(pathname) << std::endl;
                  std::cout << "PathPtr:     " << pathname + ptr << " " << strlen(pathname + ptr) << std::endl;
                  std::cout << "Path so far: "; std::cout.write(pathname, files[i].path_length+1); std::cout << std::endl;
                }
              return lookup(pathname, ptr + ntbl_entry_len + 1, 
                            nametable_encode(pathname[files[i].path_length+1]) + files[i].nametable_offset, depth+1);
            }
        }
    }
}

std::vector<std::string>
TLJPak::guess(int entry)
{
  assert(entry >= 0);
  assert(entry < file_count);
  assert(files[entry].is_file());

  std::string pathname = &nametable[files[entry].nametable_index];
  std::vector<std::string> guesses;
  guess_lookup(entry, entry, pathname, files[entry].path_length, guesses);
  return guesses;
}

void
TLJPak::guess()
{
  for(int entry = 0; entry < file_count; ++entry)
    {
      if (files[entry].is_file()) 
        {
          std::vector<std::string> guesses;
  
          std::string pathname = &nametable[files[entry].nametable_index];
          guess_lookup(entry, entry, pathname, files[entry].path_length, guesses);

          //            if (guesses.size() == 1)
          //              std::cout << guesses[0] << std::endl;
            
          if (1)
            {
              for(int j = 0; j < int(guesses.size()); ++j)
                std::cout << entry << ") " << guesses[j] << std::endl;

              std::cout << std::endl;
            }
        }
    }
}

void
TLJPak::guess_lookup(int orig_entry, int source_entry, const std::string& pathname, int path_length, 
                     std::vector<std::string>& guesses)
{
  if (int(pathname.size()) + 1 == path_length)
    {
      //std::cout 
      //<< orig_entry << " "
      //<< nametable_decode(source_entry) << pathname << std::endl;
      guesses.push_back(nametable_decode(source_entry) + pathname);
    }
  else
    {
      for(int entry = 0; entry < file_count; ++entry)
        {
          if (!files[entry].is_file()) 
            {
              for(int j = 1; j < 43; ++j)
                {
                  if (files[entry].nametable_offset + j == source_entry
                      && files[entry].path_length + int(pathname.length()) + 2 == path_length)
                    {
                      std::ostringstream str;
                      str << &nametable[files[entry].nametable_index] << nametable_decode(j) << pathname;
                      guess_lookup(orig_entry, entry, str.str(), path_length, guesses);
                    }
                }
            }
        }
    }
}

/** Searches for \a pathname in the pack and returns the FileEntry
    that refers to the pathname */
int
TLJPak::lookup(std::string pathname)
{
  for(unsigned int i = 0; i < pathname.size(); ++i)
    pathname[i] = tolower(pathname[i]);
  //std::cout << "Lookup: " << pathname << std::endl;
  int i = nametable_encode(pathname[0]);
  return lookup(pathname.c_str(), 0, i, 0);
}

void
TLJPak::extract(int file_entry, const std::string& outfile)
{
  assert(file_entry >= 0 && file_entry < int(files.size()));
    
  create_hierachy(outfile);

  if (files[file_entry].is_file())
    {
      std::ifstream in(filename.c_str(), std::ios::binary);
      if (!in)
        throw std::runtime_error("Error: Couldn't open " + filename);

      std::vector<char> filebuf;
      filebuf.resize(files[file_entry].filesize);
      in.seekg(files[file_entry].offset, std::ios::beg);
      in.read(reinterpret_cast<char*>(&*filebuf.begin()), filebuf.size());

      std::ofstream out(outfile.c_str());
      if (!out)
        throw std::runtime_error("Error: Couldn't open " + outfile);
      out.write(reinterpret_cast<char*>(&*filebuf.begin()), filebuf.size());
      out.close();

      in.close();
    }
}

void
TLJPak::print_nametable()
{ 
  for(int i = 0; i < int(nametable.size()); ++i)
    {
      std::cout << i << ") ";
      while(nametable[i] != '\0' && i < int(nametable.size()))
        std::cout << nametable[i++];
      std::cout << std::endl;
    }
}

void
TLJPak::print_indextable()
{
  for(int i = 0; i < int(indextable.size()); ++i)
    std::cout << indextable[i] << std::endl;
}

void
TLJPak::print_file_table()
{
  if (1)
    {
      std::cout << "  Nr.     offset   filesize   NTblOffset  PathLength NTblIndex      Name" << std::endl;
      std::cout << "=================================================================================" << std::endl;
    }

  for(int i = 0; i < int(files.size()); ++i)
    printf("%4d) %10d %10d %10d %10d %10d        %s\n", 
           i,
           files[i].offset, 
           files[i].filesize,
           files[i].nametable_offset,
           files[i].path_length,
           files[i].nametable_index,
           (files[i].filesize + files[i].nametable_offset + files[i].path_length + files[i].nametable_index == 0)
           ? "(null)" : ("\"" + std::string(&nametable[files[i].nametable_index]) + "\"").c_str());
}

void
TLJPak::print_info()
{
  //std::cout << "Filename: " << filename << std::endl;
  //std::cout << "Filesize: " << st.st_size/1024/1024 << "mb (" << st.st_size << " nametable)" << std::endl;
  if (0)
    {
      std::cout << "Magic:         ";
      std::cout.write(magic, 12);
      std::cout << std::endl;

      std::cout << "File_Count:    " << file_count << std::endl;
      std::cout << "Number_Count:  " << number_count << std::endl;
      std::cout << "Nametable Count:   " << byte_count << std::endl;


      int sum = 0;
      for(int i = 0; i < int(files.size()); ++i)
        if (files[i].filesize != 0)
          sum += 1;
      std::cout << "Real Files:    " << sum << " (files with non-null filesize)" << std::endl;

      std::cout << std::endl;

      std::cout << "relative: " << indextable.back() << " < " << byte_count << std::flush;
      if (indextable.back() >= byte_count) std::cout << "!!!WRONG!!!" << std::endl; 
      else std::cout << std::endl;
    
    }
  print_nametable();
  print_file_table();
}

/* EOF */
