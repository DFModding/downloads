/*
    Dreamview - Dreamfall model viewer
    Copyright (C) 2006, Tobias Pfaff (vertigo80@gmx.net)
    -------------------------------------------------------------------------- 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
    --------------------------------------------------------------------------
    I spent a lot of time interpreting the dreamfall file formats and developing
    this tool. Feel free to use this code/the procedures for your own projects;
    but do so under the terms of the GPL and if you use major parts of it please 
    refer me.
 */
using System;
using System.Collections.Generic;
using System.IO;
using Tools;

namespace Parser
{
    enum SharkType { Empty = 0, Int, ArrayInt, Float, ArrayFloat, String, ArrayString, Sub, ArraySub };

    class SNode
    {
        public Object reference;
        public SharkType type;
        public string name;

        public int count { get { if (type == SharkType.ArrayFloat || type == SharkType.ArrayInt || type == SharkType.ArrayString || type == SharkType.ArraySub) return ((Array)reference).Length; return (type == SharkType.Sub) ? 1 : 0; } }

        public Object this[int num] { get { if (num < 0 || num >= count) return null; return (type==SharkType.Sub) ? this : ((Array)reference).GetValue(num); } }
        public Object this[string ent] { get { return entry(ent); } }

        public SNode(Object r, SharkType t, string n)
        {
            reference = r;
            type = t;
            name = n;
        }

        private SNode getNode(string name)
        {
            if (type != SharkType.Sub)
                return null;
            foreach (SNode node in (SNode[])reference)
                if (node.name == name)
                    return node;
            return null;
        }
        public SNode gosub(string path)
        {
            string next = path.Split('/')[0];
            SNode nnode = (SNode)getNode(next);
            if (nnode == null || next == path)
                return nnode;
            return nnode.gosub(path.Substring(path.IndexOf('/') + 1));
        }
        public Object entry(string name)
        {
            SNode cur = gosub(name);
            return (cur == null) ? null : cur.reference;
        }
        public Object parse(string name, string[] src, Array dst, Object nullObj)
        {
            string cur = (string)entry(name);
            for (int i = 0; i < src.Length; i++)
                if (src[i] == cur)
                    return dst.GetValue(i);
            return nullObj;
        }
        public Object get(string name, Object nullObj)
        {
            Object cur = entry(name);
            return (cur == null) ? nullObj : cur;
        }
    }
    
    class SharkFile
    {
        const string magic = "shark3d_snake_binary";
        SortedList<int, string> stringTable;
        SNode _root=null;
        int stringCount = 0;

        public SNode root { get { return _root; } }
        
        public SharkFile (string file)
        {
            stringTable = new SortedList<int, string>();
            using (BinaryReader br = new BinaryReader(File.Open(FileTools.tryOpen(file), FileMode.Open)))
            {
                // check version
                if (FileTools.readString(br) != magic || FileTools.readString(br) != "2x4")
                    throw new Exception("shark3d binary magic wrong");
                _root = new SNode(readSub(br), SharkType.Sub, "root");
            }
        }

        SNode[] readSub(BinaryReader br)
        {
            int num = FileTools.readNum(br);
            SNode[] nodes = new SNode[num];
            for (int i = 0; i < num; i++)
            {
                string name = indexString(br);
                int attachCode = br.ReadByte();
                switch (attachCode)
                {
                    case 0:
                        nodes[i] = new SNode(null, SharkType.Empty, name);
                        break;
                    case 1:
                        nodes[i] = new SNode(FileTools.readNum(br), SharkType.Int, name);
                        break;
                    case 2:
                        {
                            int[] table = new int[FileTools.readNum(br)];
                            for (int e = 0; e < table.Length; e++)
                                table[e] = FileTools.readNum(br);
                            nodes[i] = new SNode(table, SharkType.ArrayInt, name);
                        } break;
                    case 4:
                        nodes[i] = new SNode(FileTools.readEndianFloat(br), SharkType.Float, name);
                        break;
                    case 8:
                        {
                            float[] table = new float[FileTools.readNum(br)];
                            for (int e = 0; e < table.Length; e++)
                                table[e] = FileTools.readEndianFloat(br);
                            nodes[i] = new SNode(table, SharkType.ArrayFloat, name);
                        } break;
                    case 0x10:
                        nodes[i] = new SNode(indexString(br), SharkType.String, name);
                        break;
                    case 0x20:
                        {
                            string[] table = new string[FileTools.readNum(br)];
                            for (int e = 0; e < table.Length; e++)
                                table[e] = indexString(br);
                            nodes[i] = new SNode(table, SharkType.ArrayString, name);
                        } break;
                    case 0x40:
                        nodes[i] = new SNode(readSub(br), SharkType.Sub, name);
                        break;
                    case 0x80:
                        {
                            SNode[] table = new SNode[FileTools.readNum(br)];
                            for (int e = 0; e < table.Length; e++)
                                table[e] = new SNode(readSub(br), SharkType.Sub, name);
                            nodes[i] = new SNode(table, SharkType.ArraySub, name);
                        } break;                        
                    default:
                        Console.WriteLine("Unrecognized code in shark3d binary !");
                        return null;
                }
            }
            return nodes;
        }

        string indexString(BinaryReader br)
        {
            int num = FileTools.readNum(br);
            int idx = stringCount - num;
            if (num == 0)
                stringCount++;
            if (stringTable.ContainsKey(idx))
                return stringTable[idx];
            string ret = FileTools.readString(br);
            stringTable.Add(idx, ret);
            return ret;        
        }

    }
}
