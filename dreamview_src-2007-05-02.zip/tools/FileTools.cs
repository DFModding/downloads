/*
    Dreamview - Dreamfall model viewer
    Copyright (C) 2006, Tobias Pfaff (vertigo80@gmx.net)
    -------------------------------------------------------------------------- 
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
    --------------------------------------------------------------------------
    I spent a lot of time interpreting the dreamfall file formats and developing
    this tool. Feel free to use this code/the procedures for your own projects;
    but do so under the terms of the GPL and if you use major parts of it please 
    refer me.
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Runtime.InteropServices;

namespace Tools
{      
    public interface Streamable
    {
        bool load(BinaryReader br, int arg);
        void save(BinaryWriter bw);
    }
    static class FileTools
    {
        private static long posZero;

        public static bool exists(string file)
        {
            string real = realName(file);
            if (File.Exists(real))
                return true;
            if (Pak.Extractor.instance.tryExtract(file))
                return true;
            return false;
        }
        
        public static string tryOpen(string file)
        {
            string real = realName(file);
            Log.write(3, "tryopen "+file+" real "+real);               
            if (File.Exists(real))
                return real;
            if (Pak.Extractor.instance.tryExtract(file))
                return real;
            throw new Exception("file " + file + " could not be extracted");
        }
        public static string realName(string file)
        {
            if (file.Contains("\\"))
                return file;
            else
                return Global.pakPath + file.Replace('/', '\\');
        }

        public static string readString(BinaryReader br)
        {
            char c;
            string ret = "";
            while ((c = br.ReadChar()) != 0)
                ret += c;
            return ret;
        }
        public static int readNum(BinaryReader br)
        {
            int num = 0, n, shift = 0;
            do
            {
                n = br.ReadByte();
                num |= (n & 0x7f) << shift;
                shift += 7;
            } while (n >= 0x80);
            return num;
        }
        public static float readEndianFloat(BinaryReader br)
        {
            byte[] ar = new byte[4];
            for (int i = 0; i < 4; i++)
                ar[3 - i] = br.ReadByte();
            float f = BitConverter.ToSingle(ar, 0);
            return f;
        }
        public static float readFloat16(BinaryReader br)
        {
            return toFloat16(br.ReadUInt16());            
        }
        // evil proprietary floating point format of hell
        public static float toFloat16(int f)
        {
            if (f == 0) return 0;
            float sign = ((f & 0x8000) == 0) ? 1.0f : -1.0f;
            int exp = ((f & 0x7c00) >> 10) - 5;
            int mnt = (f & 0x03ff);
            if (exp == 0)
            {
                float mntV = (float)mnt / (float)0x400;
                return sign * (float)Math.Pow(2, -14) * mntV;
            }
            else
            {
                float mntV = (float)(mnt + 0x400) / (float)0x400;
                return sign * (float)Math.Pow(2, exp - 15) * mntV;
            }
        }
        public static float readFixed16(BinaryReader br)
        {
            return (float)br.ReadUInt16() / (float)0x10000;
        }

        public static void zeroPos(long pos) { posZero = pos; }
        public static void zeroPos(BinaryReader br) { posZero = br.BaseStream.Position; }

        public static void assume(BinaryReader br, int num, uint c)
        {
            for (int i = 0; i < num; i++)
                if (br.ReadUInt32() != c)
                    throw new Exception(String.Format("field assumption failed at {0:x8} : {1}x({2:x}) expected",br.BaseStream.Position,num,c));
        }
        public static bool isPos(BinaryReader br, uint npos)
        {
            long pos = (npos == 0) ? 0 : (npos + posZero);
            return pos == br.BaseStream.Position;
        }
        public static void assert(BinaryReader br, uint npos)
        {
            assert0(br, (npos == 0) ? 0 : (npos + posZero));
        }
        public static void assert0(BinaryReader br, long pos)
        {
            if (pos > 0 && br.BaseStream.Position != pos)
                throw new Exception(String.Format("assert failed : pos {0:x8} exp {1:x8} : diff {2}", br.BaseStream.Position, pos, pos - br.BaseStream.Position));
        }
        public static ushort[] readU16Table(BinaryReader br, int len, uint pos)
        {
            assert(br, pos);            
            byte[] buffer = br.ReadBytes(len * 2);
            ushort[] table = new ushort[len];
            for (int i = 0; i < len; i++)
                table[i] = BitConverter.ToUInt16(buffer, 2 * i);
            return table;
        }
        public static float[] readF16Table(BinaryReader br, int len)
        {
            byte[] buffer = br.ReadBytes(len * 2);
            float[] table = new float[len];
            for (int i = 0; i < len; i++)
                table[i] = toFloat16(BitConverter.ToUInt16(buffer, 2 * i));
            return table;
        }
        public static uint[] readU32Table(BinaryReader br, int len, uint pos)
        {
            assert(br, pos);
            byte[] buffer = br.ReadBytes(len * 4);
            uint[] table = new uint[len];
            for (int i = 0; i < len; i++)
                table[i] = BitConverter.ToUInt32(buffer, 4 * i);
            return table;
        }
        public static float[] readFloatTable(BinaryReader br, int len, uint pos)
        {
            assert(br, pos);
            byte[] buffer = br.ReadBytes(len * 4);
            float[] table = new float[len];
            for (int i = 0; i < len; i++)
                table[i] = BitConverter.ToSingle(buffer, 4 * i);
            return table;
        }
        public static int[] readI32Table(BinaryReader br, int len, uint pos)
        {
            assert(br, pos);
            byte[] buffer = br.ReadBytes(len * 4);
            int[] table = new int[len];
            for (int i = 0; i < len; i++)
                table[i] = BitConverter.ToInt32(buffer, 4 * i);
            return table;
        }
        public static short[] readI16Table(BinaryReader br, int len, uint pos)
        {
            assert(br, pos);
            byte[] buffer = br.ReadBytes(len * 2);
            short[] table = new short[len];
            for (int i = 0; i < len; i++)
                table[i] = BitConverter.ToInt16(buffer, 2 * i);
            return table;
        }
        public static void writeChars(BinaryWriter bw, string s, int num)
        {
            byte[] buf = new byte[num];
            if (s.Length > num)
                throw new Exception("String too long for datafield");
            ASCIIEncoding.ASCII.GetBytes(s).CopyTo(buf,0);
            bw.Write(buf);
        }
        public static void write(BinaryWriter bw, float[] ar) { if (ar == null) return; for (int i = 0; i < ar.Length; i++) bw.Write(ar[i]); }
        public static void write(BinaryWriter bw, int[] ar) { if (ar == null) return; for (int i = 0; i < ar.Length; i++) bw.Write(ar[i]); }
        public static void write(BinaryWriter bw, uint[] ar) { if (ar == null) return; for (int i = 0; i < ar.Length; i++) bw.Write(ar[i]); }
        public static void write(BinaryWriter bw, ushort[] ar) { if (ar == null) return; for (int i = 0; i < ar.Length; i++) bw.Write(ar[i]); }
        public static void write(BinaryWriter bw, short[] ar) { if (ar == null) return; for (int i = 0; i < ar.Length; i++) bw.Write(ar[i]); }

        public static T readStructure<T>(BinaryReader br)
        {
            byte[] buffer = br.ReadBytes(Marshal.SizeOf(typeof(T)));
            GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
            T str = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
            handle.Free();
            return str;
        }
        public static void writeStructure<T>(BinaryWriter bw, T str)
        {
            byte[] buffer = new byte[Marshal.SizeOf(typeof(T))];
            GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
            Marshal.StructureToPtr(str, handle.AddrOfPinnedObject(), false);
            handle.Free();
            bw.Write(buffer);
        }
        public static T[] readStreamable<T>(BinaryReader br, int num, int arg) where T : Streamable,new()
        {
            bool abort=false;
            T[] ar = new T[num];
            for (int i = 0; i < num; i++)
            {
                ar[i] = new T();
                if (!ar[i].load(br, arg)) abort = true;
            }
            return (abort) ? null : ar;
        }
        public static void writeStreamable<T>(BinaryWriter bw, T[] ar) where T : Streamable
        {
            for (int i = 0; i < ar.Length; i++)
                ar[i].save(bw);
        }

        public static void write0Str(BinaryWriter bw, string tex)
        {
            for (int i = 0; i < tex.Length; i++)
                bw.Write((char)tex[i]);
            bw.Write((char)0);
        }
    }
}
